package com.example.mangashelf

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import org.json.JSONArray
import org.json.JSONObject
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.net.URLEncoder

class BrowserTab(val web: WebView, var workId: String?) {
    var title: String = "Nova aba"
    var url: String = ""
    /** Aba restaurada que ainda não carregou (carrega só quando for aberta). */
    var pendingUrl: String? = null
    var pendingScroll: Int = 0
    /** Posição de rolagem que ainda precisa ser reaplicada depois que a página carregar. */
    var wantScroll: Int = 0
    var tries: Int = 0
    var lastUsed: Long = 0L
}

class BrowserController(private val act: MainActivity) {
    val view = FrameLayout(act)
    private val tabs = ArrayList<BrowserTab>()
    private var active: BrowserTab? = null
    /** Cada obra só enxerga as próprias abas. null = navegador geral (sem obra). */
    private var scope: String? = null

    private fun visibleTabs(): List<BrowserTab> = tabs.filter { it.workId == scope }
    var isOpen = false
        private set
    private var fullscreen = false
    private val webHolder = FrameLayout(act)

    private lateinit var topBar: LinearLayout
    private lateinit var tabScroll: HorizontalScrollView
    private lateinit var tabStrip: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var urlField: EditText
    private lateinit var progress: ProgressBar
    private lateinit var fsButton: View
    private lateinit var btnBack: View
    private lateinit var btnFwd: View
    private lateinit var chapGroup: LinearLayout
    private lateinit var chapText: TextView

    private val handler = Handler(Looper.getMainLooper())

    init {
        view.visibility = View.GONE
        buildChrome()
    }

    // ---------- lembrar de onde parou ----------
    /** Grava abas, endereço e posição de rolagem. [persistWork] também guarda a rolagem na obra. */
    fun saveState(persistWork: Boolean) {
        try {
            if (tabs.isEmpty()) {
                act.prefs.browserState = ""
                return
            }
            val arr = JSONArray()
            var workChanged = false
            for (t in tabs) {
                val pending = t.pendingUrl != null
                val u = t.pendingUrl ?: t.url
                val y = if (pending) t.pendingScroll else if (t.wantScroll > 0) t.wantScroll else t.web.scrollY
                val o = JSONObject()
                o.put("u", u)
                o.put("t", t.title)
                o.put("w", t.workId ?: "")
                o.put("y", y)
                o.put("lu", t.lastUsed)
                arr.put(o)
                if (persistWork && !pending) {
                    val id = t.workId
                    val w = if (id != null) act.store.get(id) else null
                    if (w != null && w.lastUrl == u && w.lastScroll != y) {
                        w.lastScroll = y
                        workChanged = true
                    }
                }
            }
            val root = JSONObject()
            root.put("tabs", arr)
            root.put("active", Math.max(0, tabs.indexOf(active)))
            root.put("open", isOpen)
            act.prefs.browserState = root.toString()
            if (workChanged) act.store.save()
        } catch (e: Exception) {
            // ignora
        }
    }

    /** Recria as abas salvas. Só a aba ativa carrega agora; as outras carregam quando você abri-las. */
    fun restore(json: String) {
        val root = JSONObject(json)
        val arr = root.getJSONArray("tabs")
        if (arr.length() == 0) return
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val u = o.optString("u", "")
            if (u.isBlank()) continue
            val wid = o.optString("w", "").ifBlank { null }
            val web = WebView(act)
            val tab = BrowserTab(web, wid)
            configure(web, tab)
            tab.url = u
            tab.title = o.optString("t", "").ifBlank { u }
            tab.pendingUrl = u
            tab.pendingScroll = o.optInt("y", 0)
            tab.lastUsed = o.optLong("lu", 0L)
            tabs.add(tab)
        }
        if (tabs.isEmpty()) return
        val idx = root.optInt("active", 0).coerceIn(0, tabs.size - 1)
        val wasOpen = root.optBoolean("open", false)
        isOpen = wasOpen
        select(tabs[idx])
        if (wasOpen) {
            view.visibility = View.VISIBLE
            view.alpha = 1f
            view.bringToFront()
        }
    }

    private fun startScrollRestore(tab: BrowserTab) {
        if (tab.wantScroll <= 0) return
        tab.tries = 0
        handler.removeCallbacksAndMessages(tab)
        val step = object : Runnable {
            override fun run() {
                val y = tab.wantScroll
                if (y <= 0) return
                tab.web.scrollTo(0, y)
                tab.tries++
                if (tab.web.scrollY >= y - 8 || tab.tries >= 24) {
                    tab.wantScroll = 0
                } else {
                    handler.postAtTime(this, tab, android.os.SystemClock.uptimeMillis() + 350)
                }
            }
        }
        handler.postAtTime(step, tab, android.os.SystemClock.uptimeMillis() + 250)
    }

    private fun dp(v: Int): Int = act.dp(v)

    private fun iconBtn(ic: Ic, onClick: () -> Unit): IconView {
        val x = IconView(act, ic, P.text, 22)
        val r = dp(22).toFloat()
        x.background = act.rippled(shape(Color.TRANSPARENT, r), r)
        x.setOnClickListener { onClick() }
        return x
    }

    // ---------- interface ----------
    private fun buildChrome() {
        (webHolder.parent as? ViewGroup)?.removeView(webHolder)
        view.removeAllViews()
        webHolder.setBackgroundColor(P.bg)

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(P.bg)

        topBar = LinearLayout(act)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setBackgroundColor(P.card)
        topBar.setPadding(dp(6), dp(6), dp(6), dp(6))
        val closeBtn = iconBtn(Ic.Close) { close() }
        urlField = EditText(act)
        urlField.setSingleLine(true)
        urlField.textSize = 14f
        urlField.setTextColor(P.text)
        urlField.setHintTextColor(P.sub)
        urlField.hint = "Buscar ou digitar endereço"
        urlField.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        urlField.imeOptions = EditorInfo.IME_ACTION_GO
        urlField.setSelectAllOnFocus(true)
        urlField.setPadding(dp(14), 0, dp(14), 0)
        val ub = android.graphics.drawable.StateListDrawable()
        ub.addState(intArrayOf(android.R.attr.state_focused), shape(P.bg, dp(20).toFloat(), P.accent, dp(1)))
        ub.addState(intArrayOf(), shape(P.bg, dp(20).toFloat(), P.line, dp(1)))
        urlField.background = ub
        urlField.highlightColor = (P.accent and 0x00FFFFFF) or 0x55000000
        urlField.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                go(urlField.text.toString())
                v.hideKeyboard()
                urlField.clearFocus()
                true
            } else {
                false
            }
        }
        val menu = iconBtn(Ic.More) { showMenu() }
        topBar.addv(closeBtn, dp(40), dp(40))
        topBar.addv(urlField, 0, dp(40), 1f, 4, 0, 4, 0)
        topBar.addv(menu, dp(40), dp(40))
        col.addv(topBar)

        progress = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        progress.progressTintList = ColorStateList.valueOf(P.accent)
        progress.visibility = View.GONE
        col.addv(progress, MATCH, dp(3))

        tabStrip = LinearLayout(act)
        tabStrip.orientation = LinearLayout.HORIZONTAL
        tabStrip.gravity = Gravity.CENTER_VERTICAL
        tabStrip.setPadding(dp(6), dp(5), dp(6), dp(5))
        tabScroll = HorizontalScrollView(act)
        tabScroll.isHorizontalScrollBarEnabled = false
        tabScroll.setBackgroundColor(P.bg)
        tabScroll.addView(tabStrip)
        col.addv(tabScroll)

        col.addv(webHolder, MATCH, 0, 1f)

        bottomBar = LinearLayout(act)
        bottomBar.orientation = LinearLayout.HORIZONTAL
        bottomBar.gravity = Gravity.CENTER_VERTICAL
        bottomBar.setBackgroundColor(P.card)
        bottomBar.setPadding(dp(6), dp(4), dp(6), dp(4))
        btnBack = iconBtn(Ic.ChevronLeft) {
            val w = active?.web
            if (w != null && w.canGoBack()) w.goBack()
        }
        btnFwd = iconBtn(Ic.ChevronRight) {
            val w = active?.web
            if (w != null && w.canGoForward()) w.goForward()
        }
        val reload = iconBtn(Ic.Refresh) { active?.web?.reload() }
        bottomBar.addv(btnBack, dp(44), dp(44))
        bottomBar.addv(btnFwd, dp(44), dp(44))
        bottomBar.addv(reload, dp(44), dp(44))
        bottomBar.addv(View(act), 0, 0, 1f)

        chapGroup = LinearLayout(act)
        chapGroup.orientation = LinearLayout.HORIZONTAL
        chapGroup.gravity = Gravity.CENTER_VERTICAL
        chapGroup.background = shape(P.bg, dp(22).toFloat(), P.line, dp(1))
        chapText = act.tv("Cap. 0", 13f, P.text, true)
        chapText.gravity = Gravity.CENTER
        chapGroup.addv(iconBtn(Ic.Minus) { bumpChapter(-1) }, dp(40), dp(40))
        chapGroup.addv(chapText, WRAP, WRAP, 0f, 4, 0, 4, 0)
        val chapPlus = iconBtn(Ic.Plus) { bumpChapter(1) }
        chapPlus.color = P.accent
        chapGroup.addv(chapPlus, dp(40), dp(40))
        bottomBar.addv(chapGroup, WRAP, WRAP)
        col.addv(bottomBar)

        view.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        fsButton = IconView(act, Ic.Minimize, Color.WHITE, 22)
        fsButton.background = shape(0x99000000.toInt(), dp(22).toFloat())
        fsButton.setOnClickListener { toggleFullscreen() }
        val flp = FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END or Gravity.BOTTOM)
        flp.setMargins(0, 0, dp(14), dp(28))
        view.addView(fsButton, flp)

        refreshTabs()
        refreshNav()
        refreshChapterBar()
        val a = active
        if (a != null) urlField.setText(a.url)
        applyFullscreen()
    }

    /** Escurece os sites quando o app está no tema escuro (e a opção está ligada). */
    @Suppress("DEPRECATION")
    private fun applyWebTheme(web: WebView) {
        web.setBackgroundColor(P.bg)
        val on = P.dark && act.prefs.webDark
        if (Build.VERSION.SDK_INT >= 33) {
            web.settings.isAlgorithmicDarkeningAllowed = on
        } else if (Build.VERSION.SDK_INT >= 29) {
            web.settings.forceDark = if (on) WebSettings.FORCE_DARK_ON else WebSettings.FORCE_DARK_OFF
        }
    }

    fun retheme() {
        buildChrome()
        for (t in tabs) applyWebTheme(t.web)
    }

    private fun refreshTabs() {
        tabStrip.removeAllViews()
        for (t in visibleTabs()) {
            val sel = t === active
            val chip = LinearLayout(act)
            chip.orientation = LinearLayout.HORIZONTAL
            chip.gravity = Gravity.CENTER_VERTICAL
            chip.setPadding(dp(12), dp(6), dp(4), dp(6))
            chip.background = if (sel) shape(P.accentSoft, dp(18).toFloat(), P.accent, dp(1))
            else shape(P.card, dp(18).toFloat(), P.line, dp(1))
            val title = act.tv(t.title.ifBlank { "Nova aba" }, 12f, if (sel) P.text else P.sub, sel)
            title.maxLines = 1
            title.ellipsize = TextUtils.TruncateAt.END
            title.maxWidth = dp(120)
            chip.addv(title, WRAP, WRAP)
            val x = IconView(act, Ic.Close, if (sel) P.accent else P.sub, 14)
            x.setOnClickListener { closeTab(t) }
            chip.addv(x, dp(28), dp(24), 0f, 2, 0, 0, 0)
            chip.setOnClickListener { select(t) }
            tabStrip.addv(chip, WRAP, WRAP, 0f, 0, 0, 6, 0)
        }
        val plus = IconView(act, Ic.Plus, P.accent, 18)
        plus.background = act.rippled(shape(P.card, dp(18).toFloat(), P.line, dp(1)), dp(18).toFloat())
        plus.setOnClickListener { newTab(null, scope) }
        tabStrip.addv(plus, dp(44), dp(34))
    }

    private fun refreshNav() {
        val w = active?.web
        btnBack.alpha = if (w != null && w.canGoBack()) 1f else 0.35f
        btnFwd.alpha = if (w != null && w.canGoForward()) 1f else 0.35f
    }

    private fun refreshChapterBar() {
        val id = active?.workId
        val w = if (id != null) act.store.get(id) else null
        if (w == null) {
            chapGroup.visibility = View.GONE
        } else {
            chapGroup.visibility = View.VISIBLE
            chapText.text = "Cap. ${fmtNum(w.current)}"
        }
    }

    private fun bumpChapter(delta: Int) {
        val id = active?.workId ?: return
        val w = act.store.get(id) ?: return
        val v = if (delta > 0) Math.floor(w.current) + 1 else Math.max(0.0, Math.ceil(w.current) - 1)
        w.setChapter(v)
        act.store.save()
        refreshChapterBar()
    }

    // ---------- abas ----------
    private fun configure(web: WebView, tab: BrowserTab) {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(false)
        s.allowFileAccess = false
        s.textZoom = act.prefs.zoom
        applyWebTheme(web)
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(web, true)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString() ?: return false
                val ok = u.startsWith("http://") || u.startsWith("https://") ||
                    u.startsWith("about:") || u.startsWith("data:") || u.startsWith("blob:")
                return !ok
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url != null) tab.url = url
                if (tab === active) {
                    if (!urlField.hasFocus()) urlField.setText(tab.url)
                    refreshNav()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url != null) tab.url = url
                val t = view?.title
                tab.title = if (!t.isNullOrBlank()) t else tab.url
                if (tab.url.startsWith("http")) act.prefs.addHistory(tab.title, tab.url)
                track(tab, tab.url)
                if (tab === active) {
                    if (!urlField.hasFocus()) urlField.setText(tab.url)
                    refreshNav()
                }
                refreshTabs()
                startScrollRestore(tab)
                saveState(false)
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                if (url != null) {
                    tab.url = url
                    track(tab, url)
                    if (tab === active && !urlField.hasFocus()) urlField.setText(url)
                }
                if (tab === active) refreshNav()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (tab === active) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress in 1..99 && !fullscreen) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (!title.isNullOrBlank()) {
                    tab.title = title
                    refreshTabs()
                }
            }
        }

        web.setDownloadListener { url, _, _, _, _ -> openExternal(url) }
        // se você encostar na tela, para de reposicionar a rolagem
        web.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) tab.wantScroll = 0
            false
        }
    }

    private fun track(tab: BrowserTab, url: String?) {
        val id = tab.workId ?: return
        val u = url ?: return
        if (!u.startsWith("http")) return
        val w = act.store.get(id) ?: return
        val host = hostOf(u)
        // páginas de busca / página inicial não contam como "onde parei"
        if (host.contains("google.") || host.contains("bing.com") || host.contains("duckduckgo.com")) return
        if (w.lastUrl != u) {
            w.lastUrl = u
            w.lastScroll = 0
            w.lastRead = System.currentTimeMillis()
            act.store.save()
        }
    }

    fun newTab(url: String?, workId: String?) {
        val web = WebView(act)
        val tab = BrowserTab(web, workId)
        configure(web, tab)
        tabs.add(tab)
        select(tab)
        val target = url ?: act.prefs.homeUrl
        tab.url = target
        urlField.setText(target)
        val wk = if (workId != null) act.store.get(workId) else null
        if (wk != null && wk.lastUrl == target) tab.wantScroll = wk.lastScroll
        web.loadUrl(target)
        saveState(false)
    }

    private fun select(t: BrowserTab) {
        active = t
        scope = t.workId
        t.lastUsed = System.currentTimeMillis()
        (t.web.parent as? ViewGroup)?.removeView(t.web)
        webHolder.removeAllViews()
        webHolder.addView(t.web, FrameLayout.LayoutParams(MATCH, MATCH))
        urlField.setText(t.url)
        progress.visibility = View.GONE
        refreshTabs()
        refreshNav()
        refreshChapterBar()
        val pend = t.pendingUrl
        if (pend != null) {
            t.pendingUrl = null
            t.wantScroll = t.pendingScroll
            t.web.loadUrl(pend)
        }
        saveState(false)
    }

    private fun disposeTab(t: BrowserTab) {
        handler.removeCallbacksAndMessages(t)
        disposeWeb(t.web)
    }

    private fun disposeWeb(w: WebView) {
        (w.parent as? ViewGroup)?.removeView(w)
        w.stopLoading()
        w.destroy()
    }

    private fun closeTab(t: BrowserTab) {
        val vis = visibleTabs()
        val idx = vis.indexOf(t)
        if (!tabs.remove(t)) return
        if (t === active) {
            val rest = visibleTabs()
            if (rest.isEmpty()) {
                active = null
                webHolder.removeAllViews()
                disposeTab(t)
                refreshTabs()
                close()
                return
            }
            select(rest[Math.max(0, Math.min(idx, rest.size - 1))])
        }
        disposeTab(t)
        refreshTabs()
        saveState(false)
    }

    /** Fecha só as abas do contexto atual (da obra aberta, ou do navegador geral). */
    private fun closeAll() {
        val copy = ArrayList(visibleTabs())
        tabs.removeAll(copy.toSet())
        active = null
        webHolder.removeAllViews()
        for (t in copy) disposeTab(t)
        refreshTabs()
        close()
    }

    // ---------- abrir / fechar ----------
    fun open(url: String?, workId: String?, reuse: Boolean) {
        isOpen = true
        view.animate().cancel()
        if (view.visibility != View.VISIBLE) {
            view.alpha = 0f
            view.visibility = View.VISIBLE
            view.animate().alpha(1f).setDuration(170).start()
        } else {
            view.alpha = 1f
        }
        view.bringToFront()
        if (url == null) {
            // navegador geral: só abas que não pertencem a nenhuma obra
            scope = null
            val a = active
            val pick = if (a != null && a.workId == null) a
            else tabs.filter { it.workId == null }.maxByOrNull { it.lastUsed }
            if (pick != null) select(pick) else newTab(null, null)
            return
        }
        scope = workId
        if (reuse && workId != null) {
            val ex = tabs.filter { it.workId == workId }.maxByOrNull { it.lastUsed }
            if (ex != null) {
                select(ex)
                return
            }
        }
        newTab(url, workId)
    }

    fun close() {
        exitFullscreen()
        view.hideKeyboard()
        isOpen = false
        saveState(true)
        view.animate().cancel()
        view.animate().alpha(0f).setDuration(140).withEndAction {
            view.visibility = View.GONE
            view.alpha = 1f
        }.start()
        act.render()
    }

    fun onBack() {
        if (fullscreen) {
            exitFullscreen()
            return
        }
        val w = active?.web
        if (w != null && w.canGoBack()) w.goBack() else close()
    }

    fun pause() {
        saveState(true)
        active?.web?.onPause()
    }

    fun resume() {
        active?.web?.onResume()
    }

    fun destroy() {
        for (t in tabs) disposeTab(t)
        tabs.clear()
        active = null
    }

    // ---------- entrada de endereço ----------
    private fun resolveInput(text: String): String {
        val t = text.trim()
        if (t.isEmpty()) return ""
        if (t.contains("://")) return t
        if (!t.contains(" ") && t.contains(".")) return "https://$t"
        return "https://www.google.com/search?q=" + URLEncoder.encode(t, "UTF-8")
    }

    private fun go(input: String) {
        val u = resolveInput(input)
        if (u.isEmpty()) return
        val a = active
        if (a == null) newTab(u, scope) else a.web.loadUrl(u)
    }

    private fun openExternal(url: String?) {
        if (url.isNullOrBlank()) return
        try {
            act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            act.toast("Não consegui abrir no navegador externo")
        }
    }

    // ---------- menu ----------
    private fun showMenu() {
        val items = listOf(
            Pair(Ic.Plus, "Nova aba"),
            Pair(Ic.External, "Abrir no navegador externo"),
            Pair(Ic.ZoomIn, "Aumentar texto"),
            Pair(Ic.ZoomOut, "Diminuir texto"),
            Pair(Ic.Maximize, "Tela cheia"),
            Pair(Ic.Clock, "Histórico"),
            Pair(Ic.Copy, "Copiar endereço"),
            Pair(Ic.Trash, if (scope != null) "Fechar as abas desta obra" else "Fechar todas as abas"),
            Pair(Ic.Help, "Ajuda do navegador"),
            Pair(Ic.Moon, if (act.prefs.webDark) "Sites no escuro: ligado (tocar p/ desligar)" else "Sites no escuro: desligado (tocar p/ ligar)")
        ).toMutableList()
        val hasWork = active?.workId?.let { act.store.get(it) } != null
        if (hasWork) items.add(Pair(Ic.Chain, "Salvar site nos links desta obra"))
        act.iconListDialog("Navegador", items) { i ->
            when (i) {
                0 -> newTab(null, null)
                1 -> openExternal(active?.url)
                2 -> setZoom(act.prefs.zoom + 10)
                3 -> setZoom(act.prefs.zoom - 10)
                4 -> toggleFullscreen()
                5 -> showHistory()
                6 -> {
                    val u = active?.url ?: ""
                    if (u.isNotBlank()) {
                        val cb = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cb.setPrimaryClip(ClipData.newPlainText("url", u))
                        act.toast("Endereço copiado")
                    }
                }
                7 -> act.confirmDialog("Fechar abas", if (scope != null) "Fechar todas as abas desta obra e sair do navegador?" else "Fechar todas as abas e sair do navegador?") { closeAll() }
                8 -> MaterialAlertDialogBuilder(act).setTitle("Ajuda do navegador")
                    .setMessage(browserHelpText()).setPositiveButton("Entendi", null).show()
                9 -> {
                    act.prefs.webDark = !act.prefs.webDark
                    for (t in tabs) {
                        applyWebTheme(t.web)
                        t.web.reload()
                    }
                    act.toast(if (act.prefs.webDark) "Sites escurecidos no tema escuro" else "Sites com o visual original")
                }
                10 -> saveCurrentAsLink()
                else -> {}
            }
        }
    }

    /** Guarda a página aberta nos links da obra (para lembrar de sites diferentes depois). */
    private fun saveCurrentAsLink() {
        val t = active ?: return
        val w = t.workId?.let { act.store.get(it) } ?: return
        val u = t.url
        if (!u.startsWith("http")) {
            act.toast("Abra um site primeiro")
            return
        }
        if (w.links.any { it.url == u }) {
            act.toast("Esse endereço já está nos links")
            return
        }
        val label = hostOf(u).ifEmpty { t.title.ifBlank { "Site" } }
        w.links.add(Link(label, u, w.links.isEmpty()))
        act.store.save()
        act.toast("Salvo nos links de ${w.title} (${w.links.size})")
    }

    fun setZoom(v: Int) {
        val z = v.coerceIn(50, 300)
        act.prefs.zoom = z
        for (t in tabs) t.web.settings.textZoom = z
        act.toast("Texto: $z%")
    }

    private fun showHistory() {
        val h = act.prefs.history()
        if (h.isEmpty()) {
            act.toast("Histórico vazio")
            return
        }
        val labels = h.map { (if (it.title.isBlank()) it.url else it.title).take(60) + "\n" + it.url.take(70) }
            .toTypedArray()
        MaterialAlertDialogBuilder(act).setTitle("Histórico")
            .setItems(labels) { _, i -> go(h[i].url) }
            .setNeutralButton("Limpar") { _, _ -> act.prefs.clearHistory() }
            .setNegativeButton("Fechar", null).show()
    }

    // ---------- tela cheia ----------
    private fun toggleFullscreen() {
        fullscreen = !fullscreen
        applyFullscreen()
    }

    private fun exitFullscreen() {
        if (fullscreen) {
            fullscreen = false
            applyFullscreen()
        }
    }

    private fun applyFullscreen() {
        val vis = if (fullscreen) View.GONE else View.VISIBLE
        topBar.visibility = vis
        tabScroll.visibility = vis
        bottomBar.visibility = vis
        if (fullscreen) progress.visibility = View.GONE
        fsButton.visibility = if (fullscreen) View.VISIBLE else View.GONE
        val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
        if (fullscreen) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}
