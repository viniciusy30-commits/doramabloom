package com.doramabloom.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class Genre(
    val key: String,
    val label: String,
    val icon: String,
    /** Cor escolhida para o gênero (a de verdade; no modo escuro, veja [primary]). */
    val base: Int,
    val softL: Int,
    val darkL: Int,
    val petals: List<String>,
    /** Frase da nota 8 (as notas 9 e 10 têm frases próprias: [line9] e [line10]). */
    val tagline: String,
    val custom: Boolean = false,
    /** Frase das notas 1 a 4. */
    val lowLine: String = DEFAULT_LOW_LINE,
    /** Frase das notas 5 a 7. */
    val midLine: String = DEFAULT_MID_LINE,
    /** Frase da nota 9. */
    val line9: String = DEFAULT_LINE_9,
    /** Frase da nota 10. */
    val line10: String = DEFAULT_LINE_10,
    /** Cores extras para mesclar com a principal (vazio = cor única). */
    val extra: List<Int> = emptyList()
) {
    /** Todas as cores do gênero, sem repetir (a primeira é a principal). */
    val colors: List<Int> get() = (listOf(primary) + extra).distinct()

    /** Cor principal; no modo escuro as muito escuras (preto, cinza) são clareadas para aparecer. */
    val primary: Int
        get() {
            if (!Palette.dark) return base
            val lum = (0.299f * Color.red(base) + 0.587f * Color.green(base) + 0.114f * Color.blue(base)) / 255f
            // preto/cinza escuro de verdade: mantém a cor escolhida (não clareia para cinza)
            val neutral = maxOf(Color.red(base), Color.green(base), Color.blue(base)) -
                minOf(Color.red(base), Color.green(base), Color.blue(base)) < 24
            if (neutral && lum < 0.30f) return base
            return if (lum < 0.30f) mixColor(base, Color.WHITE, 0.45f) else base
        }

    /** Tom de fundo suave: claro no modo claro, escuro com um toque da cor no modo escuro. */
    val soft: Int
        get() = if (Palette.dark) mixColor(Color.parseColor("#251B24"), primary, 0.22f) else softL

    /** Cor de texto/ícone sobre o tom suave: escura no modo claro, clara no modo escuro. */
    val dark: Int
        get() = if (Palette.dark) mixColor(primary, Color.WHITE, 0.55f) else darkL

    /** Tom escuro de verdade (para fundos com texto branco por cima), igual nos dois modos. */
    val deep: Int get() = darkL
}

const val DEFAULT_LOW_LINE = "Terminei por educação"
const val DEFAULT_MID_LINE = "Tá ok, mas cadê o plot? \uD83D\uDDFF"
const val DEFAULT_LINE_9 = "Quase perfeito, amei demais!"
const val DEFAULT_LINE_10 = "Nota máxima: obra-prima do meu coração!"

/** Frase do gênero de acordo com a nota do dorama: sem nota nenhuma, 1-4 educação, 5-7 meme, 8-9 a frase do gênero e 10 uma frase só dela. */
fun Genre.lineFor(score: Int): String = when {
    score <= 0 -> ""
    score <= 4 -> lowLine.ifBlank { DEFAULT_LOW_LINE }
    score <= 7 -> midLine.ifBlank { DEFAULT_MID_LINE }
    score <= 9 -> tagline
    else -> line10.ifBlank { DEFAULT_LINE_10 }
}

/** Mistura duas cores (f = 0 fica em a, f = 1 fica em b). */
fun mixColor(a: Int, b: Int, f: Float): Int {
    val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt()
    val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt()
    val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt()
    return Color.rgb(r.coerceIn(0, 255), g.coerceIn(0, 255), bl.coerceIn(0, 255))
}

object Genres {
    private fun c(s: String): Int = Color.parseColor(s)

    private val factory: List<Genre> = listOf(
        Genre("romance", "Romance", "heart", c("#FF6B9D"), c("#FFE4EE"), c("#A3305B"),
            listOf("petal", "blossom", "sparkle"), "Para suspirar abraçada na almofada",
            line9 = "Suspirei tanto que faltou ar, amei demais", line10 = "Final perfeito: meu coração virou geleia e não quer voltar"),
        Genre("lgbt", "LGBTQ+", "rainbow", c("#E8505B"), mixColor(c("#E8505B"), Color.WHITE, 0.84f), mixColor(c("#E8505B"), Color.BLACK, 0.42f),
            listOf("rainbow", "heart", "sparkle"), "Amor sem rótulo e orgulho em cada cena",
            line9 = "Representatividade linda: eu me vi em cada cena", line10 = "Arco-íris completo: amei, chorei e me senti em casa",
            extra = listOf(c("#FF7A3D"), c("#F5D547"), c("#5DB56E"), c("#4F6D9A"), c("#A068E0"))),
        Genre("comedia", "Comédia", "smile", c("#FFB84D"), c("#FFF3D6"), c("#8A5A00"),
            listOf("star", "sparkle"), "Risadinhas garantidas",
            line9 = "Chorei de rir, a barriga até doeu", line10 = "Obra-prima do humor: ri do começo ao fim sem parar"),
        Genre("acao", "Ação", "bolt", c("#FF7A6B"), c("#FFE5E0"), c("#9C2F22"),
            listOf("bolt", "flame", "shield"), "Coração acelerado e muita adrenalina",
            line9 = "Adrenalina nas alturas, nem pisquei", line10 = "Perfeito: o coração disparou do início ao fim"),
        Genre("terror", "Terror", "ghost", c("#9B7EDE"), c("#EDE6FA"), c("#4B2E8F"),
            listOf("ghost", "bat", "tomb"), "Luz acesa e coberta até o nariz",
            line9 = "Dormir de luz acesa foi pouco, que medo bom", line10 = "Obra-prima do pavor: nunca mais olho o escuro igual"),
        Genre("fantasia", "Fantasia", "sparkle", c("#6FA8FF"), c("#E3EEFF"), c("#1F4F9C"),
            listOf("sparkle", "butterfly", "wand"), "Magia, brilho e mundos encantados",
            line9 = "Um mundo encantado que eu não queria deixar", line10 = "Pura magia: queria morar dentro dessa história"),
        Genre("historico", "Histórico", "pagoda", c("#D6536D"), c("#FBE3E8"), c("#8E1F3A"),
            listOf("pagoda", "lantern", "fan"), "Hanboks, palácios e intrigas da corte",
            line9 = "Intrigas e palácio de tirar o fôlego", line10 = "Joia da coroa: majestoso do primeiro ao último ep"),
        Genre("misterio", "Mistério", "search", c("#5FB3A8"), c("#DFF4F1"), c("#1F6B62"),
            listOf("search", "key", "lock"), "Quem será o culpado?",
            line9 = "A cada pista eu mudava de culpado", line10 = "Reviravolta perfeita: não vi o final chegando"),
        Genre("escolar", "Escolar", "school", c("#7FD1AE"), c("#E1F7EC"), c("#226B4B"),
            listOf("school", "book", "pencil"), "Uniformes, amizades e primeiros amores",
            line9 = "Deu saudade da escola e do primeiro amor", line10 = "Perfeito: virei estudante de novo e chorei na formatura"),
        Genre("drama", "Drama", "drop", c("#C38BD8"), c("#F6E6FB"), c("#6E2F86"),
            listOf("drop", "cloud", "heartbreak"), "Lencinho por perto, vai ter choro",
            line9 = "Gastei a caixa de lenços e valeu cada lágrima", line10 = "Choro bonito: me destruiu e me curou ao mesmo tempo"),
        Genre("suspense", "Suspense", "eye", c("#4F6D9A"), c("#E3EAF5"), c("#24395A"),
            listOf("eye", "moon", "clock"), "Segura a respiração, a trama não dá trégua",
            line9 = "Prendi a respiração até o último episódio", line10 = "Tensão perfeita: não consegui nem pausar"),
        Genre("medico", "Médico", "cross", c("#3FB6C9"), c("#DDF4F8"), c("#17657A"),
            listOf("cross", "pill", "syringe"), "Plantões, jalecos e corações em tratamento",
            line9 = "Plantão que cura o coração e a alma", line10 = "Receita perfeita: alta médica para o meu coração, só amor"),
        Genre("familia", "Família", "home", c("#F29B5C"), c("#FFEBDC"), c("#96501A"),
            listOf("home", "cake", "gift"), "Mesa farta, abraço apertado e muito afeto",
            line9 = "Aqueceu o coração, quis abraçar todo mundo", line10 = "Abraço eterno: a família que eu queria chamar de minha"),
        Genre("musical", "Musical", "music", c("#E36BC4"), c("#FDE4F6"), c("#8A2A72"),
            listOf("music", "mic", "headphones"), "Melodias que grudam no coração",
            line9 = "Trilha na cabeça por dias e eu não me importo", line10 = "Perfeito: cada música virou parte de mim"),
        Genre("esporte", "Esporte", "trophy", c("#5DB56E"), c("#E1F5E5"), c("#226B35"),
            listOf("trophy", "medal", "ball"), "Suor, garra e superação em campo",
            line9 = "Vibrei, torci e suei junto em cada jogo", line10 = "Campeão absoluto: medalha de ouro no meu coração"),
        Genre("realeza", "Realeza", "crown", c("#E0A93B"), c("#FFF1CC"), c("#7A5A00"),
            listOf("crown", "gem", "castle"), "Coroas, tronos e segredos do palácio",
            line9 = "Coroa merecida: trono, segredos e muito brilho", line10 = "Majestade absoluta: reinou no meu coração"),
        Genre("scifi", "Ficção científica", "rocket", c("#6C63FF"), c("#E7E5FF"), c("#2E2A99"),
            listOf("rocket", "planet", "ufo"), "Futuro, viagens no tempo e mistérios do espaço",
            line9 = "Futuro fascinante, minha cabeça explodiu", line10 = "Obra-prima do tempo e do espaço: infinito de bom"),
        Genre("vida", "Vida real", "coffee", c("#C79A7B"), c("#F6E9DF"), c("#6B4630"),
            listOf("coffee", "leaf", "sun"), "Cotidiano gostoso, café quentinho e paz",
            line9 = "Aconchego puro, quis morar nesse cotidiano", line10 = "Paz perfeita: um abraço quentinho em forma de dorama"),
        Genre("vinganca", "Vingança", "skull", c("#B03A5B"), c("#F8DDE5"), c("#5E1128"),
            listOf("skull", "dagger", "hourglass"), "Frieza, planos e a hora do acerto de contas",
            line9 = "Acerto de contas de arrepiar, frio e genial", line10 = "Vingança perfeita: servida fria e impecável"),
        Genre("crime", "Crime", "lock", c("#8A94A6"), c("#E6E9EF"), c("#3C4452"),
            listOf("lock", "key", "eye"), "Sirenes, pistas e um caso para resolver",
            line9 = "Caso fechado com chave de ouro, quase perfeito", line10 = "Caso perfeito: impecável do primeiro ao último ep")
    )

    private var edits: Map<String, Genre> = emptyMap()
    private var builtin: List<Genre> = factory
    private var extra: List<Genre> = emptyList()

    /** Edições que você fez nos gêneros de fábrica (chave -> gênero editado). */
    fun setEdits(m: Map<String, Genre>) {
        edits = m
        builtin = factory.map { edits[it.key] ?: it }
    }

    fun edited(): Map<String, Genre> = edits

    fun isEdited(k: String): Boolean = edits.containsKey(k)

    fun factoryOf(k: String): Genre? = factory.firstOrNull { it.key == k }

    /** Gênero de fábrica com nome, ícone, cor e frase novos (mantém o resto se a cor não mudou). */
    fun editBuiltin(base: Genre, label: String, icon: String, primary: Int, tagline: String, low: String = "", mid: String = "", l9: String = "", l10: String = "", extra: List<Int>? = null): Genre {
        val orig = factoryOf(base.key) ?: base
        val ex = (extra ?: if (primary == orig.base) orig.extra else emptyList()).filter { it != primary }.distinct()
        val n9 = if (l9.isBlank()) orig.line9 else l9
        val n10 = if (l10.isBlank()) orig.line10 else l10
        val tag = if (tagline.isBlank()) orig.tagline else tagline
        val lo = if (low.isBlank()) DEFAULT_LOW_LINE else low
        val mi = if (mid.isBlank()) DEFAULT_MID_LINE else mid
        val pet = if (icon == orig.icon) orig.petals else (listOf(icon) + orig.petals.drop(1)).distinct()
        return if (primary == orig.base) {
            orig.copy(label = label, icon = icon, tagline = tag, petals = pet, lowLine = lo, midLine = mi, line9 = n9, line10 = n10, extra = ex)
        } else {
            orig.copy(
                label = label, icon = icon, base = primary,
                softL = mixColor(primary, Color.WHITE, 0.84f),
                darkL = mixColor(primary, Color.BLACK, 0.42f),
                tagline = tag, petals = pet, lowLine = lo, midLine = mi, line9 = n9, line10 = n10, extra = ex
            )
        }
    }

    /** Ordem escolhida por você (lista de chaves). Gêneros fora da lista ficam no fim, na ordem de sempre. */
    private var order: List<String> = emptyList()

    fun order(): List<String> = order

    fun setOrder(l: List<String>) {
        order = l.distinct()
    }

    /** Os gêneros de fábrica (com suas edições) e os que você criou, na ordem que você escolheu. */
    val all: List<Genre> get() {
        val base = builtin + extra
        if (order.isEmpty()) return base
        val pos = HashMap<String, Int>()
        for ((i, k) in order.withIndex()) pos[k] = i
        return base.withIndex()
            .sortedWith(compareBy({ pos[it.value.key] ?: Int.MAX_VALUE }, { it.index }))
            .map { it.value }
    }

    fun custom(): List<Genre> = extra

    fun setCustom(l: List<Genre>) {
        extra = l
    }

    fun exists(k: String): Boolean = all.any { it.key == k }

    fun byKey(k: String): Genre = all.firstOrNull { it.key == k } ?: builtin[0]

    /** Monta um gênero novo a partir de nome, ícone e cor; o resto (tons claro e escuro) sai da cor. */
    fun makeCustom(key: String, label: String, icon: String, primary: Int, tagline: String, low: String = "", mid: String = "", l9: String = "", l10: String = "", extra: List<Int> = emptyList()): Genre =
        Genre(
            key, label, icon, primary,
            mixColor(primary, Color.WHITE, 0.84f),
            mixColor(primary, Color.BLACK, 0.42f),
            listOf(icon, "sparkle", "petal").distinct(),
            if (tagline.isBlank()) "Seu gênero $label" else tagline,
            true,
            if (low.isBlank()) DEFAULT_LOW_LINE else low,
            if (mid.isBlank()) DEFAULT_MID_LINE else mid,
            if (l9.isBlank()) DEFAULT_LINE_9 else l9,
            if (l10.isBlank()) DEFAULT_LINE_10 else l10,
            extra.filter { it != primary }.distinct()
        )
}

/**
 * "Outros gêneros": etiquetas só para classificar e filtrar.
 * Não têm tema próprio (cor, símbolos e pétalas continuam sendo os do gênero principal),
 * então escolher um deles nunca muda a atmosfera das telas.
 * Ficam guardados no mesmo campo "tags" do dorama, com chave começando em "x_".
 */
class OtherGenre(
    val key: String,
    val label: String,
    val icon: String,
    val color: Int,
    val custom: Boolean = false,
    /** Cores extras para mesclar (a principal é [color]). */
    val extra: List<Int> = emptyList()
) {
    /** Todas as cores, sem repetir (a primeira é a principal). */
    val colors: List<Int> get() = (listOf(color) + extra).distinct()
    val soft: Int get() = mixColor(color, Color.WHITE, 0.84f)
    val dark: Int get() = mixColor(color, Color.BLACK, 0.42f)
}

object OtherGenres {
    private fun c(s: String): Int = Color.parseColor(s)

    /** Cada um tem cor e símbolo só dele (nenhum repete os símbolos dos gêneros com tema). */
    val factory: List<OtherGenre> = listOf(
        OtherGenre("x_policial", "Policial", "shield", c("#5B7FD9")),
        OtherGenre("x_juridico", "Jurídico", "scale", c("#8A6D5A")),
        OtherGenre("x_politico", "Político", "flag", c("#E8505B")),
        OtherGenre("x_sobrenatural", "Sobrenatural", "moon", c("#7B6CF0")),
        OtherGenre("x_zumbi", "Zumbi", "tomb", c("#7A9A5A")),
        OtherGenre("x_vampiro", "Vampiro", "bat", c("#9E1F4D")),
        OtherGenre("x_viagem_tempo", "Viagem no tempo", "hourglass", c("#E0A93B")),
        OtherGenre("x_reencarnacao", "Reencarnação", "replay", c("#2BA6A0")),
        OtherGenre("x_superpoderes", "Superpoderes", "flame", c("#FF7A3D")),
        OtherGenre("x_distopia", "Distopia", "globe", c("#4A8FA8")),
        OtherGenre("x_militar", "Militar", "medal", c("#6B7A3A")),
        OtherGenre("x_trabalho", "Trabalho", "chart", c("#3E6FD8")),
        OtherGenre("x_chaebol", "Chaebol", "gem", c("#D45FA0")),
        OtherGenre("x_casamento", "Casamento por contrato", "ring", c("#FF8FB7")),
        OtherGenre("x_amizade", "Amizade", "person", c("#F29B5C")),
        OtherGenre("x_lgbt", "LGBTQ+", "rainbow", c("#E8505B"), false,
            listOf(c("#FF7A3D"), c("#F5D547"), c("#5DB56E"), c("#4F6D9A"), c("#A068E0"))),
        OtherGenre("x_slice", "Slice of life", "leaf", c("#6FBF4A")),
        OtherGenre("x_culinario", "Culinário", "cake", c("#D98B5F")),
        OtherGenre("x_moda", "Moda", "butterfly", c("#E36BC4")),
        OtherGenre("x_idol", "Idols", "mic", c("#9B5DE5")),
        OtherGenre("x_superacao", "Superação", "sun", c("#F2A93B"))
    )

    private var edits: Map<String, OtherGenre> = emptyMap()
    private var builtin: List<OtherGenre> = factory
    private var extraList: List<OtherGenre> = emptyList()
    private var hidden: Set<String> = emptySet()

    /** Gêneros de fábrica que você apagou. */
    fun hiddenKeys(): Set<String> = hidden

    fun setHidden(s: Set<String>) {
        hidden = s
    }

    fun setEdits(m: Map<String, OtherGenre>) {
        edits = m
        builtin = factory.map { edits[it.key] ?: it }
    }

    fun edited(): Map<String, OtherGenre> = edits

    fun isEdited(k: String): Boolean = edits.containsKey(k)

    fun factoryOf(k: String): OtherGenre? = factory.firstOrNull { it.key == k }

    /** De fábrica (com suas edições) e depois os que você criou. */
    val all: List<OtherGenre> get() = builtin.filter { !hidden.contains(it.key) } + extraList

    fun custom(): List<OtherGenre> = extraList

    fun setCustom(l: List<OtherGenre>) {
        extraList = l
    }

    fun makeCustom(key: String, label: String, icon: String, color: Int, extra: List<Int>): OtherGenre =
        OtherGenre(key, label, icon, color, true, extra.filter { it != color }.distinct())

    /** Edita um gênero de fábrica (nome, símbolo e cores); a chave continua a mesma. */
    fun editBuiltin(base: OtherGenre, label: String, icon: String, color: Int, extra: List<Int>): OtherGenre =
        OtherGenre(base.key, label, icon, color, false, extra.filter { it != color }.distinct())

    fun exists(k: String): Boolean = all.any { it.key == k }

    fun byKey(k: String): OtherGenre = all.first { it.key == k }
}

/** Três tons do gênero para as pétalas: uma mistura rica em vez de uma cor só. */
fun genreTints(g: Genre): List<Int> = listOf(
    g.primary,
    mixColor(g.primary, g.dark, 0.32f),
    mixColor(g.primary, Color.WHITE, 0.28f)
)

data class Status(val key: String, val label: String, val icon: String, val color: Int)

object Statuses {
    val all: List<Status> = listOf(
        Status("assistindo", "Assistindo", "play", Color.parseColor("#6FA8FF")),
        Status("quero", "Quero ver", "bookmark", Color.parseColor("#C38BD8")),
        Status("concluido", "Concluído", "check", Color.parseColor("#5CC6A0")),
        Status("pausado", "Pausado", "pause", Color.parseColor("#FFB84D")),
        Status("dropado", "Dropado", "close", Color.parseColor("#B7A3AE"))
    )

    fun byKey(k: String): Status = all.firstOrNull { it.key == k } ?: all[1]
}

val countries: List<String> = listOf(
    "Coreia do Sul", "Japão", "China", "Tailândia", "Taiwan", "Outro"
)

/** Ator ou atriz do elenco, com foto opcional (caminho do arquivo) e o nome do personagem que fez. */
class CastPerson(var name: String, var photo: String = "", var role: String = "", var gender: String = "")

/**
 * Perfil de um ator ou atriz (vale para todos os doramas em que o nome aparece).
 * A chave é o nome sem acento, maiúscula ou pontuação, então "Lee Min-ho" e "lee min ho" são a mesma pessoa.
 * [photo] é a foto escolhida (arquivo próprio, em files/people); vazia = usa uma foto do elenco.
 * [gender] é "m" (ator), "f" (atriz) ou vazio (ainda sem classificar).
 */
data class PersonInfo(
    var key: String,
    var name: String,
    var gender: String = "",
    var photo: String = "",
    var birth: String = "",
    var note: String = "",
    var favorite: Boolean = false,
    /** Nota que você mesmo deu à pessoa (0 a 10; 0 = sem nota). Vale no desempate do Top 10. */
    var rating: Double = 0.0
)

data class Drama(
    var id: Long,
    var title: String,
    var original: String,
    var synopsis: String,
    var country: String,
    var genre: String,
    var tags: List<String>,
    var status: String,
    var score: Int,
    var seasonEps: List<Int>,
    var watched: List<Int>,
    var epMinutes: Int,
    var year: String,
    var platform: String,
    var cast: String,
    var couple: String,
    var startDate: Long,
    var endDate: Long,
    var rewatch: Int,
    var notes: String,
    var favorite: Boolean,
    var cover: String,
    var addedAt: Long,
    var link: String = "",
    var lastUrl: String = "",
    var watchSeason: Int = -1,
    /** Posição na sua ordem manual (0 = ainda sem posição, aparece no topo). */
    var order: Long = 0L,
    /** "serie" ou "filme". */
    var kind: String = "serie",
    /** Arquivo de áudio da trilha sonora (cópia dentro do app); vazio = sem trilha. */
    var soundtrack: String = "",
    /** Nome da música (aparece no player da página do dorama); vazio = só "Trilha sonora". */
    var soundtrackName: String = "",
    var castPeople: List<CastPerson> = emptyList(),
    var couplePhoto: String = "",
    /** Até 3 gêneros extras escolhidos para aparecer no cartão da Estante (vazio = os 3 primeiros). */
    var shelfTags: List<String> = emptyList(),
    /** Supremacy: os pouquíssimos doramas acima de todos os favoritos. */
    var supremacy: Boolean = false,
    /** Posição na ordem de favoritismo da aba Supremacy (0 = sem posição: fica depois dos outros, por nota). */
    var supOrder: Long = 0L,
    /** Data de lançamento (só para filmes; 0 = não informada). */
    var releaseDate: Long = 0L
)

/**
 * Anos de lançamento: aceita 2019, 19 ou várias temporadas ("19-22", "2019, 2020, 2022") e deixa tudo em
 * 4 dígitos. Com mais de um ano vira o período, por exemplo "2019–2022".
 */
fun normalizeYears(raw: String): String {
    val ys = Regex("\\d+").findAll(raw).mapNotNull { m ->
        val n = m.value
        val v = n.toIntOrNull() ?: return@mapNotNull null
        when (n.length) {
            2 -> if (v <= 69) 2000 + v else 1900 + v
            4 -> v
            else -> null
        }
    }.toList()
    if (ys.isEmpty()) return raw.trim()
    val lo = ys.minOrNull() ?: 0
    val hi = ys.maxOrNull() ?: 0
    return if (lo == hi) lo.toString() else "$lo–$hi"
}

/** Gêneros extras que aparecem no cartão da Estante: os escolhidos (até 3) ou, sem escolha, os 3 primeiros. */
fun shelfPick(d: Drama): List<String> {
    val avail = d.tags.filter { it != d.genre && (Genres.exists(it) || OtherGenres.exists(it)) }
    val chosen = d.shelfTags.filter { avail.contains(it) }.distinct().take(3)
    return if (chosen.isNotEmpty()) chosen else avail.take(3)
}

fun totalEps(d: Drama): Int = d.seasonEps.sum()
fun watchedEps(d: Drama): Int = d.watched.sum()
fun seasonCount(d: Drama): Int = d.seasonEps.size

fun allTotalsKnown(d: Drama): Boolean = d.seasonEps.all { it > 0 }

fun seasonDone(d: Drama, i: Int): Boolean =
    i in d.seasonEps.indices && d.seasonEps[i] > 0 && d.watched[i] >= d.seasonEps[i]

fun currentSeason(d: Drama): Int {
    for (i in d.seasonEps.indices) {
        val t = d.seasonEps[i]
        if (t == 0 || d.watched[i] < t) return i
    }
    return maxOf(0, d.seasonEps.size - 1)
}

/**
 * Temporada em que você está: a mais avançada que já tem episódio assistido;
 * se ela já terminou e existe a próxima, é a próxima. (Não depende mais da aba escolhida no
 * navegador, que antes ficava presa na T1.)
 */
fun activeSeason(d: Drama): Int {
    var last = -1
    for (i in d.seasonEps.indices) if (d.watched[i] > 0) last = i
    if (last < 0) return 0
    if (seasonDone(d, last) && last + 1 < d.seasonEps.size) return last + 1
    return last
}

/** Quantos episódios ainda faltam (só conta temporadas com total conhecido). */
fun remainingEps(d: Drama): Int {
    var r = 0
    for (i in d.seasonEps.indices) if (d.seasonEps[i] > 0) r += maxOf(0, d.seasonEps[i] - d.watched[i])
    return r
}

/** "Temp. 2" ou "" quando só há uma temporada. */
fun seasonTag(d: Drama): String = if (seasonCount(d) > 1) "Temp. " + (activeSeason(d) + 1) else ""

/** "Ep. 3/12" da temporada atual. */
fun epTag(d: Drama): String {
    val s = activeSeason(d)
    val t = d.seasonEps[s]
    return if (t > 0) "Ep. " + d.watched[s] + "/" + t else "Ep. " + d.watched[s]
}

/** Texto do contador do navegador, ex.: "T2 · Ep. 5/12". */
fun counterText(d: Drama, s: Int): String {
    val t = d.seasonEps[s]
    val w = d.watched[s]
    val ep = if (t > 0) "Ep. $w/$t" else "Ep. $w"
    return if (seasonCount(d) > 1) "T${s + 1} · $ep" else ep
}

fun progressText(d: Drama): String {
    if (d.kind == "filme") return if (watchedEps(d) > 0) "Filme assistido" else "Filme"
    val t = totalEps(d)
    val w = watchedEps(d)
    if (seasonCount(d) <= 1) {
        return if (t > 0) "Ep. $w de $t" else "Ep. $w"
    }
    val cs = activeSeason(d)
    val st = d.seasonEps[cs]
    val part = if (st > 0) "${d.watched[cs]}/$st" else "${d.watched[cs]}"
    return "Temp. ${cs + 1} · Ep. $part"
}

fun progressOf(d: Drama): Float {
    var t = 0
    var w = 0
    for (i in d.seasonEps.indices) {
        if (d.seasonEps[i] > 0) {
            t += d.seasonEps[i]
            w += minOf(d.watched[i], d.seasonEps[i])
        }
    }
    return if (t > 0) w.toFloat() / t.toFloat() else 0f
}

fun subtitle(d: Drama): String {
    val parts = ArrayList<String>()
    parts.add(d.country)
    if (d.year.isNotBlank()) parts.add(d.year)
    if (seasonCount(d) > 1) parts.add(seasonCount(d).toString() + " temp.")
    val t = totalEps(d)
    if (t > 0) parts.add(t.toString() + " eps")
    return parts.joinToString(" · ")
}

/** Ordem manual: quem tem posição vem pela posição; os novos (sem posição) ficam no topo. */
fun manualOrder(l: List<Drama>): List<Drama> =
    l.sortedWith(compareBy<Drama> { it.order }.thenByDescending { it.addedAt })

fun hoursWatched(d: Drama): Double =
    watchedEps(d) * (if (d.epMinutes > 0) d.epMinutes else 60) / 60.0

fun normalize(d: Drama) {
    val e = d.seasonEps.toMutableList()
    val w = d.watched.toMutableList()
    if (e.isEmpty()) e.add(0)
    while (w.size < e.size) w.add(0)
    while (w.size > e.size) w.removeAt(w.size - 1)
    for (i in e.indices) {
        if (e[i] < 0) e[i] = 0
        if (w[i] < 0) w[i] = 0
        if (e[i] > 0 && w[i] > e[i]) w[i] = e[i]
    }
    d.seasonEps = e
    d.watched = w
    if (d.watchSeason < -1 || d.watchSeason >= e.size) d.watchSeason = -1
}

fun applyStatus(d: Drama, key: String) {
    d.status = key
    val now = System.currentTimeMillis()
    if (key == "assistindo" && d.startDate == 0L) d.startDate = now
    if (key == "concluido") {
        val w = ArrayList<Int>()
        for (i in d.seasonEps.indices) {
            w.add(if (d.seasonEps[i] > 0) d.seasonEps[i] else d.watched[i])
        }
        d.watched = w
        if (d.startDate == 0L) d.startDate = now
        if (d.endDate == 0L) d.endDate = now
    }
}

private fun intsToJson(l: List<Int>): JSONArray {
    val a = JSONArray()
    for (v in l) a.put(v)
    return a
}

private fun jsonInts(a: JSONArray?): List<Int> {
    val r = ArrayList<Int>()
    if (a != null) {
        for (i in 0 until a.length()) r.add(a.optInt(i, 0))
    }
    return r
}

private fun jsonStrings(a: JSONArray?): List<String> {
    val r = ArrayList<String>()
    if (a != null) {
        for (i in 0 until a.length()) r.add(a.optString(i, ""))
    }
    return r
}

/** Lê o elenco; backups antigos (só texto "A, B, C") viram pessoas sem foto. */
private fun castFromJson(a: JSONArray?, oldText: String): List<CastPerson> {
    val r = ArrayList<CastPerson>()
    if (a != null && a.length() > 0) {
        for (i in 0 until a.length()) {
            val po = a.optJSONObject(i) ?: continue
            val n = po.optString("name", "").trim()
            if (n.isNotEmpty()) r.add(CastPerson(n, po.optString("photo", ""), po.optString("role", "").trim()))
        }
    } else {
        for (n in oldText.split(",", ";", "/")) {
            val t = n.trim()
            if (t.isNotEmpty()) r.add(CastPerson(t, ""))
        }
    }
    return r
}

private fun Drama.toJson(): JSONObject {
    val o = JSONObject()
    o.put("id", id)
    o.put("title", title)
    o.put("original", original)
    o.put("synopsis", synopsis)
    o.put("country", country)
    o.put("genre", genre)
    val ta = JSONArray()
    for (t in tags) ta.put(t)
    o.put("tags", ta)
    o.put("status", status)
    o.put("score", score)
    o.put("seasonEps", intsToJson(seasonEps))
    o.put("watched", intsToJson(watched))
    o.put("epMinutes", epMinutes)
    o.put("year", year)
    o.put("platform", platform)
    o.put("cast", cast)
    o.put("couple", couple)
    o.put("startDate", startDate)
    o.put("endDate", endDate)
    o.put("rewatch", rewatch)
    o.put("notes", notes)
    o.put("favorite", favorite)
    o.put("cover", cover)
    o.put("addedAt", addedAt)
    o.put("link", link)
    o.put("lastUrl", lastUrl)
    o.put("watchSeason", watchSeason)
    o.put("order", order)
    o.put("kind", kind)
    o.put("soundtrack", soundtrack)
    o.put("soundtrackName", soundtrackName)
    o.put("couplePhoto", couplePhoto)
    o.put("shelfTags", JSONArray().also { a -> for (t in shelfTags) a.put(t) })
    o.put("supremacy", supremacy)
    o.put("supOrder", supOrder)
    o.put("releaseDate", releaseDate)
    val cp = JSONArray()
    for (p in castPeople) {
        val po = JSONObject()
        po.put("name", p.name)
        po.put("photo", p.photo)
        po.put("role", p.role)
        cp.put(po)
    }
    o.put("castPeople", cp)
    return o
}

private fun dramaFromJson(o: JSONObject): Drama {
    var eps = jsonInts(o.optJSONArray("seasonEps"))
    var wat = jsonInts(o.optJSONArray("watched"))
    if (eps.isEmpty()) {
        // versão antiga: um único bloco de episódios
        eps = listOf(o.optInt("epTotal", 0))
        wat = listOf(o.optInt("epWatched", 0))
    }
    val score = if (o.has("score")) o.optInt("score", 0) else o.optInt("rating", 0) * 2
    val d = Drama(
        id = o.optLong("id", System.currentTimeMillis()),
        title = o.optString("title", ""),
        original = o.optString("original", ""),
        synopsis = o.optString("synopsis", ""),
        country = o.optString("country", countries[0]),
        genre = o.optString("genre", "romance"),
        tags = jsonStrings(o.optJSONArray("tags")),
        status = o.optString("status", "quero"),
        score = score,
        seasonEps = eps,
        watched = wat,
        epMinutes = o.optInt("epMinutes", 0),
        year = o.optString("year", ""),
        platform = o.optString("platform", ""),
        cast = o.optString("cast", ""),
        couple = o.optString("couple", ""),
        startDate = o.optLong("startDate", 0L),
        endDate = o.optLong("endDate", 0L),
        rewatch = o.optInt("rewatch", 0),
        notes = o.optString("notes", ""),
        favorite = o.optBoolean("favorite", false),
        cover = o.optString("cover", ""),
        addedAt = o.optLong("addedAt", System.currentTimeMillis()),
        link = o.optString("link", ""),
        lastUrl = o.optString("lastUrl", ""),
        watchSeason = o.optInt("watchSeason", -1),
        order = o.optLong("order", 0L),
        kind = o.optString("kind", "serie"),
        soundtrack = o.optString("soundtrack", ""),
        soundtrackName = o.optString("soundtrackName", ""),
        castPeople = castFromJson(o.optJSONArray("castPeople"), o.optString("cast", "")),
        couplePhoto = o.optString("couplePhoto", ""),
        shelfTags = jsonStrings(o.optJSONArray("shelfTags")),
        supremacy = o.optBoolean("supremacy", false),
        supOrder = o.optLong("supOrder", 0L),
        releaseDate = o.optLong("releaseDate", 0L)
    )
    normalize(d)
    return d
}

private fun colorsOf(o: JSONObject): List<Int> {
    val a = o.optJSONArray("extra") ?: return emptyList()
    return (0 until a.length()).map { a.optInt(it) }
}

object Store {
    private const val PREF = "doramabloom"
    private const val KEY = "dramas"

    private lateinit var prefs: SharedPreferences
    lateinit var appContext: Context
    private val list = ArrayList<Drama>()
    private var loaded = false

    /** Sobe a cada gravação; as telas usam para saber se precisam se atualizar. */
    var version = 0
        private set

    fun init(c: Context) {
        if (loaded) return
        appContext = c.applicationContext
        prefs = appContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        loadGenres()
        loadGenreEdits()
        loadGenreOrder()
        loadOtherGenres()
        load()
        loadPeople()
        loadWd()
        loaded = true
    }

    const val DEFAULT_HOME = "https://www.google.com"

    /** Aparência do app: 0 = seguir o sistema, 1 = claro, 2 = escuro. */
    var themeMode: Int
        get() = prefs.getInt("themeMode", 0)
        set(v) {
            prefs.edit().putInt("themeMode", v).apply()
        }

    var textZoom: Int
        get() = prefs.getInt("textZoom", 100)
        set(v) {
            prefs.edit().putInt("textZoom", v).apply()
        }

    var homeUrl: String
        get() {
            val u = prefs.getString("homeUrl", DEFAULT_HOME) ?: DEFAULT_HOME
            return if (u.isBlank()) DEFAULT_HOME else u
        }
        set(v) {
            prefs.edit().putString("homeUrl", v).apply()
        }

    var userName: String
        get() = prefs.getString("userName", "") ?: ""
        set(v) {
            prefs.edit().putString("userName", v).apply()
        }

    var askedName: Boolean
        get() = prefs.getBoolean("askedName", false)
        set(v) {
            prefs.edit().putBoolean("askedName", v).apply()
        }

    /** Rascunho do formulário de dorama (para não perder o que você digitou ao sair do app). */
    fun saveDraft(id: Long, d: Drama, created: List<String>) {
        try {
            val o = d.toJson()
            val ca = JSONArray()
            for (c in created) ca.put(c)
            o.put("_created", ca)
            prefs.edit().putString("draft_$id", o.toString()).apply()
        } catch (e: Exception) {
        }
    }

    fun loadDraft(id: Long): Pair<Drama, List<String>>? {
        return try {
            val t = prefs.getString("draft_$id", null) ?: return null
            val o = JSONObject(t)
            val ca = o.optJSONArray("_created")
            val created = if (ca == null) emptyList() else (0 until ca.length()).map { ca.optString(it) }.filter { it.isNotEmpty() }
            Pair(dramaFromJson(o), created)
        } catch (e: Exception) {
            null
        }
    }

    fun clearDraft(id: Long) {
        if (prefs.contains("draft_$id")) prefs.edit().remove("draft_$id").apply()
    }

    /** Ordem escolhida à mão no Top 10 ("m" = atores, "f" = atrizes): lista de chaves de pessoas. */
    fun actorOrder(g: String): List<String> {
        return try {
            val arr = JSONArray(prefs.getString("actorOrder_$g", "[]") ?: "[]")
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun setActorOrder(g: String, keys: List<String>) {
        val arr = JSONArray()
        for (k in keys) arr.put(k)
        prefs.edit().putString("actorOrder_$g", arr.toString()).apply()
        version++
    }

    /**
     * Critério de desempate do Top 10 quando duas pessoas têm o mesmo número de doramas:
     * "avg" = nota média dos doramas (padrão), "hours" = horas de tela somadas, "manual" = a nota que você deu à pessoa.
     */
    var tiebreak: String
        get() {
            val v = prefs.getString("tiebreak", "avg") ?: "avg"
            return if (v == "hours" || v == "manual") v else "avg"
        }
        set(v) {
            prefs.edit().putString("tiebreak", v).apply()
            version++
        }

    /**
     * Como o Top 10 é ordenado: "count" = mais doramas (padrão), "avg" = maior nota média, "hours" = horas de tela,
     * "manual" = a nota que você deu à pessoa, "custom" = a ordem que você arrastou em Reordenar.
     * Fora de "custom", a ordem arrastada é ignorada, então trocar o critério sempre muda o pódio.
     */
    var podiumSort: String
        get() {
            val v = prefs.getString("podiumSort", "count") ?: "count"
            return if (v == "avg" || v == "hours" || v == "manual" || v == "custom") v else "count"
        }
        set(v) {
            prefs.edit().putString("podiumSort", v).apply()
            version++
        }

    /** true só na primeira vez que é chamada com esta etiqueta (para ajustes que rodam uma vez depois de uma atualização). */
    fun runOnce(tag: String): Boolean {
        if (prefs.getBoolean("once_$tag", false)) return false
        prefs.edit().putBoolean("once_$tag", true).apply()
        return true
    }

    private const val GKEY = "customGenres"

    private fun genreToJson(g: Genre): JSONObject {
        val o = JSONObject()
        o.put("key", g.key)
        o.put("label", g.label)
        o.put("icon", g.icon)
        o.put("color", g.base)
        o.put("tagline", g.tagline)
        o.put("low", g.lowLine)
        o.put("mid", g.midLine)
        o.put("l9", g.line9)
        o.put("l10", g.line10)
        o.put("extra", JSONArray(g.extra))
        return o
    }

    private fun loadGenres() {
        val r = ArrayList<Genre>()
        try {
            val arr = JSONArray(prefs.getString(GKEY, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val k = o.optString("key", "")
                val l = o.optString("label", "")
                if (k.isBlank() || l.isBlank()) continue
                r.add(
                    Genres.makeCustom(
                        k, l, o.optString("icon", "heart"),
                        o.optInt("color", Palette.pink), o.optString("tagline", ""), o.optString("low", ""), o.optString("mid", ""), o.optString("l9", ""), o.optString("l10", ""), colorsOf(o)
                    )
                )
            }
        } catch (e: Exception) {
            // dados corrompidos: sem gêneros próprios
        }
        Genres.setCustom(r)
    }

    private const val GORDKEY = "genreOrder"

    private fun loadGenreOrder() {
        val l = ArrayList<String>()
        try {
            val arr = JSONArray(prefs.getString(GORDKEY, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val k = arr.optString(i, "")
                if (k.isNotBlank()) l.add(k)
            }
        } catch (e: Exception) {
            // dados corrompidos: ordem de fábrica
        }
        Genres.setOrder(l)
    }

    /** Salva a ordem dos gêneros (Estante, Configurações e escolha de gênero seguem essa ordem). */
    fun setGenreOrder(keys: List<String>) {
        Genres.setOrder(keys)
        version++
        prefs.edit().putString(GORDKEY, JSONArray(Genres.order()).toString()).apply()
    }

    private fun genreOrderJson(): JSONArray = JSONArray(Genres.order())

    private fun applyGenreOrder(a: JSONArray?) {
        if (a == null) return
        val l = ArrayList<String>()
        for (i in 0 until a.length()) {
            val k = a.optString(i, "")
            if (k.isNotBlank()) l.add(k)
        }
        setGenreOrder(l)
    }

    private const val EKEY = "genreEdits"

    private fun loadGenreEdits() {
        val m = HashMap<String, Genre>()
        try {
            val arr = JSONArray(prefs.getString(EKEY, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val g = editFromJson(o) ?: continue
                m[g.key] = g
            }
        } catch (e: Exception) {
            // dados corrompidos: sem edições
        }
        Genres.setEdits(m)
    }

    /** Lê uma edição de gênero de fábrica; devolve null se a chave não for de fábrica. */
    private fun editFromJson(o: JSONObject): Genre? {
        val k = o.optString("key", "")
        val base = Genres.factoryOf(k) ?: return null
        val l = o.optString("label", "").trim()
        if (l.isEmpty()) return null
        return Genres.editBuiltin(
            base, l, o.optString("icon", base.icon),
            o.optInt("color", base.base), o.optString("tagline", ""), o.optString("low", ""), o.optString("mid", ""), o.optString("l9", ""), o.optString("l10", ""),
            if (o.has("extra")) colorsOf(o) else null
        )
    }

    private const val OKEY = "customOthers"
    private const val OEKEY = "otherEdits"
    private const val OHKEY = "otherHidden"

    private fun otherToJson(g: OtherGenre): JSONObject {
        val o = JSONObject()
        o.put("key", g.key)
        o.put("label", g.label)
        o.put("icon", g.icon)
        o.put("color", g.color)
        val ex = JSONArray()
        for (c in g.extra) ex.put(c)
        o.put("extra", ex)
        return o
    }

    private fun otherFromJson(o: JSONObject, custom: Boolean): OtherGenre? {
        val k = o.optString("key", "")
        val l = o.optString("label", "").trim()
        if (k.isBlank() || l.isEmpty()) return null
        val ic = o.optString("icon", "tag")
        val col = o.optInt("color", Palette.pink)
        val ex = ArrayList<Int>()
        val ea = o.optJSONArray("extra")
        if (ea != null) for (i in 0 until ea.length()) ex.add(ea.optInt(i))
        return if (custom) {
            OtherGenres.makeCustom(k, l, ic, col, ex)
        } else {
            val base = OtherGenres.factoryOf(k) ?: return null
            OtherGenres.editBuiltin(base, l, ic, col, ex)
        }
    }

    private fun parseOthers(arr: JSONArray?, custom: Boolean): List<OtherGenre> {
        val r = ArrayList<OtherGenre>()
        if (arr == null) return r
        for (i in 0 until arr.length()) {
            var g: OtherGenre? = null
            try {
                g = otherFromJson(arr.getJSONObject(i), custom)
            } catch (e: Exception) {
                // item inválido: ignora
            }
            if (g == null) continue
            if (r.any { it.key == g.key }) continue
            r.add(g)
        }
        return r
    }

    private fun loadOtherGenres() {
        try {
            val c = parseOthers(JSONArray(prefs.getString(OKEY, "[]") ?: "[]"), true)
            OtherGenres.setCustom(c)
            val m = HashMap<String, OtherGenre>()
            for (g in parseOthers(JSONArray(prefs.getString(OEKEY, "[]") ?: "[]"), false)) m[g.key] = g
            OtherGenres.setEdits(m)
            val hs = HashSet<String>()
            val ha = JSONArray(prefs.getString(OHKEY, "[]") ?: "[]")
            for (i in 0 until ha.length()) hs.add(ha.optString(i, ""))
            OtherGenres.setHidden(hs)
        } catch (e: Exception) {
            // dados corrompidos: sem outros gêneros próprios
        }
    }

    private fun persistOthers() {
        version++
        val arr = JSONArray()
        for (g in OtherGenres.custom()) arr.put(otherToJson(g))
        val earr = JSONArray()
        for (g in OtherGenres.edited().values) earr.put(otherToJson(g))
        val harr = JSONArray()
        for (k in OtherGenres.hiddenKeys()) harr.put(k)
        prefs.edit().putString(OKEY, arr.toString()).putString(OEKEY, earr.toString()).putString(OHKEY, harr.toString()).apply()
    }

    /** Salva a edição de um "outro gênero" (criado por você ou de fábrica). */
    fun updateOtherGenre(g: OtherGenre) {
        if (g.custom) {
            OtherGenres.setCustom(OtherGenres.custom().map { if (it.key == g.key) g else it })
        } else {
            val m = HashMap(OtherGenres.edited())
            m[g.key] = g
            OtherGenres.setEdits(m)
        }
        persistOthers()
    }

    fun resetOtherGenre(key: String) {
        val m = HashMap(OtherGenres.edited())
        m.remove(key)
        OtherGenres.setEdits(m)
        persistOthers()
    }

    fun addOtherGenre(g: OtherGenre) {
        val l = ArrayList(OtherGenres.custom())
        l.removeAll { it.key == g.key }
        l.add(g)
        OtherGenres.setCustom(l)
        persistOthers()
    }

    /** Apaga um "outro gênero" criado por você; ele sai das etiquetas dos doramas. */
    fun removeOtherGenre(key: String) {
        OtherGenres.setCustom(OtherGenres.custom().filter { it.key != key })
        var changed = false
        for (d in list) {
            if (d.tags.contains(key) || d.shelfTags.contains(key)) {
                d.tags = d.tags.filter { it != key }
                d.shelfTags = d.shelfTags.filter { it != key }
                changed = true
            }
        }
        persistOthers()
        if (changed) persist()
    }

    /** Apaga um "outro gênero" que veio com o app (volta em "Restaurar padrões"). */
    fun hideOtherGenre(key: String) {
        OtherGenres.setHidden(OtherGenres.hiddenKeys() + key)
        var changed = false
        for (d in list) {
            if (d.tags.contains(key) || d.shelfTags.contains(key)) {
                d.tags = d.tags.filter { it != key }
                d.shelfTags = d.shelfTags.filter { it != key }
                changed = true
            }
        }
        persistOthers()
        if (changed) persist()
    }

    /** Traz de volta os de fábrica apagados e desfaz as edições deles (os seus ficam). */
    fun restoreOtherDefaults() {
        OtherGenres.setHidden(emptySet())
        OtherGenres.setEdits(emptyMap())
        persistOthers()
    }

    /** Junta (ou troca, se replace) os "outros gêneros" de um backup. */
    private fun importOthers(root: JSONObject, replace: Boolean) {
        val cust = parseOthers(root.optJSONArray("otherGenres"), true)
        val eds = parseOthers(root.optJSONArray("otherEdits"), false)
        if (replace) {
            OtherGenres.setCustom(cust)
            OtherGenres.setEdits(eds.associateBy { it.key })
        } else {
            val cur = ArrayList(OtherGenres.custom())
            for (g in cust) if (!OtherGenres.exists(g.key)) cur.add(g)
            OtherGenres.setCustom(cur)
            val m = HashMap(OtherGenres.edited())
            for (g in eds) if (!m.containsKey(g.key)) m[g.key] = g
            OtherGenres.setEdits(m)
        }
        val hid = HashSet<String>(if (replace) emptySet() else OtherGenres.hiddenKeys())
        val ha = root.optJSONArray("otherHidden")
        if (ha != null) for (i in 0 until ha.length()) hid.add(ha.optString(i, ""))
        OtherGenres.setHidden(hid)
        persistOthers()
    }

    private fun persistGenres() {
        version++
        val arr = JSONArray()
        for (g in Genres.custom()) arr.put(genreToJson(g))
        val earr = JSONArray()
        for (g in Genres.edited().values) earr.put(genreToJson(g))
        prefs.edit().putString(GKEY, arr.toString()).putString(EKEY, earr.toString()).apply()
    }

    /** Salva a edição de um gênero (criado por você ou de fábrica). */
    fun updateGenre(g: Genre) {
        if (g.custom) {
            Genres.setCustom(Genres.custom().map { if (it.key == g.key) g else it })
        } else {
            val m = HashMap(Genres.edited())
            m[g.key] = g
            Genres.setEdits(m)
        }
        persistGenres()
    }

    /** Volta um gênero de fábrica ao nome, ícone e cor originais. */
    fun resetGenre(key: String) {
        val m = HashMap(Genres.edited())
        m.remove(key)
        Genres.setEdits(m)
        persistGenres()
    }

    fun addGenre(g: Genre) {
        val l = ArrayList(Genres.custom())
        l.removeAll { it.key == g.key }
        l.add(g)
        Genres.setCustom(l)
        persistGenres()
    }

    /** Apaga um gênero criado por você; os doramas dele voltam para Romance. */
    fun removeGenre(key: String) {
        Genres.setCustom(Genres.custom().filter { it.key != key })
        var changed = false
        for (d in list) {
            if (d.genre == key) {
                d.genre = "romance"
                changed = true
            }
            if (d.tags.contains(key)) {
                d.tags = d.tags.filter { it != key }
                changed = true
            }
        }
        persistGenres()
        if (changed) persist()
    }

    fun setWatchSeason(d: Drama, s: Int) {
        d.watchSeason = s
        persist()
    }

    private fun load() {
        list.clear()
        try {
            val arr = JSONArray(prefs.getString(KEY, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                list.add(dramaFromJson(arr.getJSONObject(i)))
            }
        } catch (e: Exception) {
            // dados corrompidos: começa vazio
        }
    }

    private fun persist() {
        version++
        val arr = JSONArray()
        for (d in list) arr.put(d.toJson())
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    // ------------------------------------------------------------------ PESSOAS (atores e atrizes)

    private const val PKEY = "people"
    private val peopleMap = LinkedHashMap<String, PersonInfo>()
    private var photoSeq = 0

    /** Nome sem acento, maiúscula nem pontuação: serve para saber se dois nomes são a mesma pessoa. */
    fun personKey(name: String): String {
        val n = java.text.Normalizer.normalize(name, java.text.Normalizer.Form.NFD)
        return n.replace(Regex("\\p{M}+"), "")
            .lowercase(Locale.ROOT)
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
    }

    private fun personToJson(p: PersonInfo): JSONObject {
        val o = JSONObject()
        o.put("key", p.key)
        o.put("name", p.name)
        o.put("gender", p.gender)
        o.put("photo", p.photo)
        o.put("birth", p.birth)
        o.put("note", p.note)
        o.put("favorite", p.favorite)
        if (p.rating > 0.0) o.put("rating", p.rating)
        return o
    }

    private fun personFromJson(o: JSONObject): PersonInfo? {
        val name = o.optString("name", "").trim()
        var key = o.optString("key", "")
        if (key.isBlank()) key = personKey(name)
        if (key.isBlank()) return null
        val g = o.optString("gender", "")
        return PersonInfo(
            key, if (name.isEmpty()) key else name,
            if (g == "m" || g == "f") g else "",
            o.optString("photo", ""), o.optString("birth", ""), o.optString("note", ""),
            o.optBoolean("favorite", false),
            o.optDouble("rating", 0.0).coerceIn(0.0, 10.0)
        )
    }

    private fun loadPeople() {
        peopleMap.clear()
        try {
            val arr = JSONArray(prefs.getString(PKEY, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val p = personFromJson(arr.getJSONObject(i)) ?: continue
                peopleMap[p.key] = p
            }
        } catch (e: Exception) {
            // dados corrompidos: sem perfis
        }
    }

    fun persistPeople() {
        version++
        val arr = JSONArray()
        for (p in peopleMap.values) arr.put(personToJson(p))
        prefs.edit().putString(PKEY, arr.toString()).apply()
    }

    /** O perfil da pessoa (se a chave for uma variação do nome, vale o perfil da pessoa "oficial" do grupo). */
    fun personInfo(key: String): PersonInfo? = peopleMap[PeopleIdentity.canon(key)] ?: peopleMap[key]

    fun savePersonInfo(p: PersonInfo) {
        p.key = PeopleIdentity.canon(p.key)
        peopleMap[p.key] = p
        persistPeople()
    }

    // acesso "cru" (sem juntar variações): usado só pelo reconhecimento de pessoas
    fun rawPersonInfo(key: String): PersonInfo? = peopleMap[key]
    fun putRawPerson(p: PersonInfo) {
        peopleMap[p.key] = p
    }
    fun removeRawPerson(key: String) {
        peopleMap.remove(key)
    }

    // ---- reconhecimento automático: grafia do nome -> pessoa do Wikidata (ex.: Q483669)
    private const val WDKEY = "personWd"
    private const val MISSKEY = "personAutoMiss2"
    private val wdMap = HashMap<String, String>()
    private val missMap = HashMap<String, Long>()

    private fun loadWd() {
        wdMap.clear()
        missMap.clear()
        try {
            val o = JSONObject(prefs.getString(WDKEY, "{}") ?: "{}")
            for (k in o.keys()) {
                val v = o.optString(k, "")
                if (v.isNotEmpty()) wdMap[k] = v
            }
        } catch (e: Exception) {
        }
        try {
            val o = JSONObject(prefs.getString(MISSKEY, "{}") ?: "{}")
            for (k in o.keys()) missMap[k] = o.optLong(k, 0L)
        } catch (e: Exception) {
        }
    }

    private fun saveWd() {
        val o = JSONObject()
        for ((k, v) in wdMap) o.put(k, v)
        prefs.edit().putString(WDKEY, o.toString()).apply()
    }

    fun wdOf(key: String): String = wdMap[key] ?: ""

    fun wdSnapshot(): Map<String, String> = HashMap(wdMap)

    /** Guarda quem é a pessoa (id do Wikidata) para esta grafia do nome. */
    fun setWd(key: String, qid: String) {
        if (key.isBlank() || qid.isBlank() || wdMap[key] == qid) return
        wdMap[key] = qid
        missMap.remove(key)
        saveWd()
        version++
    }

    /** Quando o app tentou reconhecer esta grafia sem achar (0 = nunca). */
    fun autoMissAt(key: String): Long = missMap[key] ?: 0L

    fun setAutoMiss(key: String) {
        missMap[key] = System.currentTimeMillis()
        val o = JSONObject()
        for ((k, v) in missMap) o.put(k, v)
        prefs.edit().putString(MISSKEY, o.toString()).apply()
    }

    fun clearAutoMiss() {
        missMap.clear()
        prefs.edit().remove(MISSKEY).apply()
    }

    /** Cópia dos perfis no momento do pedido (usada pelo backup, que grava em segundo plano). */
    fun peopleSnapshot(): List<PersonInfo> {
        for (t in 0 until 3) {
            try {
                return peopleMap.values.map { it.copy() }
            } catch (e: Exception) {
                // mudou no meio da cópia: tenta de novo
            }
        }
        return emptyList()
    }

    /** Foto de quem está no elenco de UM dorama: sempre a do próprio dorama (a foto escolhida no perfil só vale no Top 10). */
    fun castPhoto(p: CastPerson): String = p.photo

    private fun personPhotoDir(): File {
        val d = File(appContext.filesDir, "people")
        d.mkdirs()
        return d
    }

    /** Copia uma foto para a pasta das pessoas (arquivo só do perfil: não some se o dorama for apagado). */
    fun copyPersonPhoto(src: String): String? {
        return try {
            val s = File(src)
            if (!s.exists() || !s.isFile) return null
            val f = File(personPhotoDir(), "p" + System.currentTimeMillis() + "_" + (photoSeq++) + ".jpg")
            s.copyTo(f, true)
            f.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    /** Foto nova (galeria ou internet) já reduzida e guardada na pasta das pessoas. */
    fun savePersonPhoto(uri: Uri): String? {
        val tmp = saveCover(uri) ?: return null
        val r = copyPersonPhoto(tmp)
        try {
            File(tmp).delete()
        } catch (e: Exception) {
        }
        return r
    }

    fun deletePersonFile(path: String) {
        if (path.isEmpty()) return
        try {
            File(path).delete()
        } catch (e: Exception) {
        }
        Covers.clear()
    }

    /** Muda o nome da pessoa em todos os doramas e leva o perfil junto. Devolve em quantos doramas mudou. */
    fun renamePerson(oldKey: String, newName: String): Int {
        val nn = newName.trim()
        if (nn.isEmpty()) return 0
        val newKey = personKey(nn)
        if (newKey.isEmpty()) return 0
        // a pessoa pode estar escrita de várias formas nos elencos: muda todas
        val members = HashSet<String>(PeopleIdentity.membersOf(oldKey))
        members.add(oldKey)
        var n = 0
        for (d in list) {
            var hit = false
            for (p in d.castPeople) {
                if (personKey(p.name) in members) {
                    p.name = nn
                    hit = true
                }
            }
            if (hit) n++
        }
        var qid = ""
        for (m in members) {
            if (qid.isEmpty()) qid = wdOf(m)
        }
        var target: PersonInfo? = peopleMap[newKey]
        for (m in members) {
            if (m == newKey) continue
            val info = peopleMap.remove(m) ?: continue
            if (target == null) {
                info.key = newKey
                info.name = nn
                target = info
                peopleMap[newKey] = info
            } else {
                // o novo nome já tem perfil: junta, mantendo o que já estava preenchido lá
                val other = target
                if (other.gender.isEmpty()) other.gender = info.gender
                if (other.birth.isEmpty()) other.birth = info.birth
                if (other.note.isEmpty()) other.note = info.note
                if (other.photo.isEmpty()) other.photo = info.photo else if (other.photo != info.photo) deletePersonFile(info.photo)
                if (info.favorite) other.favorite = true
                if (other.rating <= 0.0) other.rating = info.rating
            }
        }
        if (target != null) target.name = nn
        if (qid.isNotEmpty()) {
            wdMap[newKey] = qid
            saveWd()
        }
        persist()
        persistPeople()
        return n
    }

    /** Devolve os perfis de um backup: foto vem de media/people/..., o resto do JSON. */
    private fun restorePeople(root: JSONObject?, media: Map<String, File>, replace: Boolean) {
        val arr = root?.optJSONArray("people") ?: return
        if (replace) {
            for (p in peopleMap.values) deletePersonFile(p.photo)
            peopleMap.clear()
        }
        val dir = personPhotoDir()
        val stamp = System.currentTimeMillis()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val p = personFromJson(o) ?: continue
            if (peopleMap.containsKey(p.key)) continue
            val entry = o.optString("photo", "")
            p.photo = ""
            val src = if (entry.isEmpty()) null else media[entry]
            if (src != null && src.exists() && src.length() > 0L) {
                val dst = File(dir, "p" + stamp + "_" + i + ".jpg")
                try {
                    if (!src.renameTo(dst)) {
                        src.copyTo(dst, true)
                        src.delete()
                    }
                    p.photo = dst.absolutePath
                } catch (e: Exception) {
                    p.photo = ""
                }
            }
            peopleMap[p.key] = p
        }
        persistPeople()
    }

    fun all(): List<Drama> = list.toList()

    fun get(id: Long): Drama? = list.firstOrNull { it.id == id }

    fun save(d: Drama) {
        normalize(d)
        val i = list.indexOfFirst { it.id == d.id }
        if (i >= 0) list[i] = d else list.add(0, d)
        persist()
    }

    fun delete(id: Long) {
        val d = get(id) ?: return
        val extras = ArrayList<String>()
        if (d.soundtrack.isNotEmpty()) extras.add(d.soundtrack)
        if (d.couplePhoto.isNotEmpty()) extras.add(d.couplePhoto)
        for (p in d.castPeople) if (p.photo.isNotEmpty()) extras.add(p.photo)
        for (f in extras) {
            try {
                File(f).delete()
            } catch (e: Exception) {
            }
        }
        if (d.cover.isNotEmpty()) {
            try {
                File(d.cover).delete()
            } catch (e: Exception) {
            }
            Covers.clear()
        }
        list.removeAll { it.id == id }
        persist()
    }

    /** Soma um episódio na temporada que você está assistindo (ou na primeira em andamento). Devolve true se acabou de concluir o dorama. */
    fun bump(d: Drama): Boolean {
        val w = d.watched.toMutableList()
        var target = -1
        val a = activeSeason(d)
        val ta = d.seasonEps[a]
        if (ta == 0 || w[a] < ta) {
            target = a
        } else {
            for (i in d.seasonEps.indices) {
                val t = d.seasonEps[i]
                if (t == 0 || w[i] < t) {
                    target = i
                    break
                }
            }
        }
        if (target < 0) return false
        w[target] = w[target] + 1
        d.watched = w
        return afterProgress(d, true)
    }

    /** Ajusta os episódios de uma temporada específica (delta positivo ou negativo). */
    fun adjust(d: Drama, season: Int, delta: Int): Boolean {
        if (season < 0 || season >= d.seasonEps.size) return false
        val w = d.watched.toMutableList()
        val t = d.seasonEps[season]
        val old = w[season]
        var nv = old + delta
        if (nv < 0) nv = 0
        if (t > 0 && nv > t) nv = t
        if (nv == old) return false
        w[season] = nv
        d.watched = w
        if (nv < old && d.status == "concluido") d.status = "assistindo"
        return afterProgress(d, nv > old)
    }

    /** Só conclui/atualiza o status quando você AVANÇOU um episódio (grew); nunca ao voltar ou sem mudar nada. */
    private fun afterProgress(d: Drama, grew: Boolean): Boolean {
        var finished = false
        val total = totalEps(d)
        if (grew && watchedEps(d) > 0 && total > 0 && d.seasonEps.all { it > 0 } && watchedEps(d) >= total) {
            if (d.status != "concluido") finished = true
            applyStatus(d, "concluido")
        } else if (grew && watchedEps(d) > 0 && d.status != "assistindo" && d.status != "concluido") {
            applyStatus(d, "assistindo")
        }
        persist()
        return finished
    }

    /**
     * Guarda a sua ordem manual. [ids] é a lista na nova ordem (pode ser só uma parte da estante,
     * por causa dos filtros): os outros doramas não saem do lugar.
     */
    fun reorder(ids: List<Long>) {
        val seq = manualOrder(list)
        for (i in seq.indices) seq[i].order = (i + 1).toLong()
        val items = ids.mapNotNull { get(it) }
        val slots = items.map { it.order }.sorted()
        for (i in items.indices) items[i].order = slots[i]
        persist()
    }

    /** Guarda a ordem de favoritismo do Supremacy: [ids] na ordem escolhida (lista vazia = volta a ordenar por nota). */
    fun setSupOrder(ids: List<Long>) {
        for (d in list) if (d.supremacy) d.supOrder = 0L
        for ((i, id) in ids.withIndex()) get(id)?.supOrder = (i + 1).toLong()
        persist()
    }

    fun setStatus(d: Drama, key: String) {
        applyStatus(d, key)
        persist()
    }

    fun persistNow() {
        persist()
    }

    fun exportJson(): String {
        val arr = JSONArray()
        for (d in list) {
            val o = d.toJson()
            o.put("cover", "")
            arr.put(o)
        }
        val ga = JSONArray()
        for (g in Genres.custom()) ga.put(genreToJson(g))
        val root = JSONObject()
        root.put("genres", ga)
        val ea = JSONArray()
        for (g in Genres.edited().values) ea.put(genreToJson(g))
        root.put("genreEdits", ea)
        root.put("genreOrder", genreOrderJson())
        root.put("otherGenres", JSONArray().also { a -> for (g in OtherGenres.custom()) a.put(otherToJson(g)) })
        root.put("otherEdits", JSONArray().also { a -> for (g in OtherGenres.edited().values) a.put(otherToJson(g)) })
        root.put("otherHidden", JSONArray().also { a -> for (k in OtherGenres.hiddenKeys()) a.put(k) })
        root.put("dramas", arr)
        return root.toString()
    }

    /** Importa um backup (novo ou antigo). Devolve quantos foram adicionados, ou -1 se o texto for inválido. */
    fun importJson(s: String): Int {
        return try {
            val t = s.trim()
            val arr: JSONArray
            if (t.startsWith("{")) {
                val root = JSONObject(t)
                val ga = root.optJSONArray("genres")
                if (ga != null) {
                    val cur = ArrayList(Genres.custom())
                    for (i in 0 until ga.length()) {
                        val o = ga.getJSONObject(i)
                        val k = o.optString("key", "")
                        val l = o.optString("label", "")
                        if (k.isBlank() || l.isBlank() || Genres.exists(k)) continue
                        cur.add(
                            Genres.makeCustom(
                                k, l, o.optString("icon", "heart"),
                                o.optInt("color", Palette.pink), o.optString("tagline", ""), o.optString("low", ""), o.optString("mid", ""), o.optString("l9", ""), o.optString("l10", ""), colorsOf(o)
                            )
                        )
                    }
                    Genres.setCustom(cur)
                    persistGenres()
                }
                val ea = root.optJSONArray("genreEdits")
                if (ea != null) {
                    val m = HashMap(Genres.edited())
                    for (i in 0 until ea.length()) {
                        val g = editFromJson(ea.getJSONObject(i)) ?: continue
                        if (!m.containsKey(g.key)) m[g.key] = g
                    }
                    Genres.setEdits(m)
                    persistGenres()
                }
                importOthers(root, false)
                arr = root.optJSONArray("dramas") ?: JSONArray()
            } else {
                arr = JSONArray(t)
            }
            var n = 0
            for (i in 0 until arr.length()) {
                val d = dramaFromJson(arr.getJSONObject(i))
                if (d.title.isBlank()) continue
                if (list.any { it.title.equals(d.title, true) && it.year == d.year }) continue
                d.cover = ""
                d.id = System.currentTimeMillis() + i
                list.add(d)
                n++
            }
            persist()
            n
        } catch (e: Exception) {
            -1
        }
    }

    // ------------------------------------------------------------------ BACKUP COMPLETO (.zip)

    fun backupFileName(): String =
        "MyDoramas-backup-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".zip"

    /** Foto da lista no momento do pedido (o arquivo é gravado em segundo plano). */
    fun backupSnapshot(): List<Drama> = list.map { it.copy() }

    private fun settingsJson(): JSONObject {
        val s = JSONObject()
        s.put("themeMode", themeMode)
        s.put("textZoom", textZoom)
        s.put("homeUrl", homeUrl)
        s.put("userName", userName)
        s.put("askedName", askedName)
        s.put("actorOrderM", JSONArray(actorOrder("m")))
        s.put("actorOrderF", JSONArray(actorOrder("f")))
        s.put("tiebreak", tiebreak)
        s.put("podiumSort", podiumSort)
        val wd = JSONObject()
        for ((k, v) in wdMap) wd.put(k, v)
        s.put("personWd", wd)
        return s
    }

    private fun extOf(path: String, fallback: String): String {
        val e = File(path).extension.lowercase(Locale.US)
        return if (e.isNotEmpty() && e.length <= 5 && e.all { it.isLetterOrDigit() }) e else fallback
    }

    /**
     * Grava o backup completo num .zip: backup.json (doramas, gêneros, ajustes) e a pasta media/
     * com TODOS os arquivos: capas, trilhas sonoras, fotos do elenco e foto do casal.
     * Devolve false se der erro.
     */
    fun writeBackup(dramas: List<Drama>, out: OutputStream, people: List<PersonInfo> = peopleSnapshot()): Boolean {
        return try {
            val zip = ZipOutputStream(BufferedOutputStream(out, 64 * 1024))
            val arr = JSONArray()
            val files = ArrayList<Pair<String, File>>()
            for (d in dramas) {
                val o = d.toJson()
                val base = "media/" + d.id + "/"
                fun add(path: String, name: String): String {
                    if (path.isEmpty()) return ""
                    val f = File(path)
                    if (!f.exists() || !f.isFile) return ""
                    files.add(Pair(base + name, f))
                    return base + name
                }
                o.put("cover", add(d.cover, "cover." + extOf(d.cover, "jpg")))
                o.put("soundtrack", add(d.soundtrack, "soundtrack." + extOf(d.soundtrack, "audio")))
                o.put("couplePhoto", add(d.couplePhoto, "couple." + extOf(d.couplePhoto, "jpg")))
                val cp = JSONArray()
                for ((i, p) in d.castPeople.withIndex()) {
                    val po = JSONObject()
                    po.put("name", p.name)
                    po.put("photo", add(p.photo, "cast" + i + "." + extOf(p.photo, "jpg")))
                    po.put("role", p.role)
                    cp.put(po)
                }
                o.put("castPeople", cp)
                arr.put(o)
            }
            val pa = JSONArray()
            for ((i, p) in people.withIndex()) {
                val po = personToJson(p)
                var entry = ""
                if (p.photo.isNotEmpty()) {
                    val f = File(p.photo)
                    if (f.exists() && f.isFile) {
                        entry = "media/people/" + i + "." + extOf(p.photo, "jpg")
                        files.add(Pair(entry, f))
                    }
                }
                po.put("photo", entry)
                pa.put(po)
            }
            val ga = JSONArray()
            for (g in Genres.custom()) ga.put(genreToJson(g))
            val ea = JSONArray()
            for (g in Genres.edited().values) ea.put(genreToJson(g))
            val root = JSONObject()
            root.put("app", "MyDoramas")
            root.put("people", pa)
            root.put("backupVersion", 3)
            root.put("createdAt", System.currentTimeMillis())
            root.put("settings", settingsJson())
            root.put("genres", ga)
            root.put("genreEdits", ea)
            root.put("genreOrder", genreOrderJson())
            root.put("otherGenres", JSONArray().also { a -> for (g in OtherGenres.custom()) a.put(otherToJson(g)) })
            root.put("otherEdits", JSONArray().also { a -> for (g in OtherGenres.edited().values) a.put(otherToJson(g)) })
            root.put("otherHidden", JSONArray().also { a -> for (k in OtherGenres.hiddenKeys()) a.put(k) })
            root.put("dramas", arr)
            zip.setLevel(6)
            zip.putNextEntry(ZipEntry("backup.json"))
            zip.write(root.toString().toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            // imagens e músicas já vêm comprimidas: guardar sem recomprimir deixa o backup bem mais rápido
            zip.setLevel(0)
            val seen = HashSet<String>()
            for (p in files) {
                if (!seen.add(p.first)) continue
                zip.putNextEntry(ZipEntry(p.first))
                FileInputStream(p.second).use { it.copyTo(zip) }
                zip.closeEntry()
            }
            zip.finish()
            zip.flush()
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Backup já aberto: o texto do backup.json e a pasta temporária com os arquivos de mídia. */
    class BackupPack(val json: String, val dir: File)

    /**
     * Passo 1 (pode rodar em segundo plano): lê o .zip aos poucos, sem carregar tudo na memória.
     * O backup.json fica em texto e os demais arquivos vão para uma pasta temporária.
     * Aceita também o backup antigo (só o texto JSON).
     */
    fun openBackup(input: InputStream): BackupPack? {
        val tmp = File(appContext.cacheDir, "restore_" + System.currentTimeMillis())
        return try {
            tmp.mkdirs()
            val head = BufferedInputStream(input, 64 * 1024)
            head.mark(4)
            val b0 = head.read()
            val b1 = head.read()
            head.reset()
            if (b0 < 0 || b1 < 0) {
                tmp.deleteRecursively()
                return null
            }
            var jsonText: String? = null
            if (b0 == 0x50 && b1 == 0x4B) {
                val z = ZipInputStream(head)
                var e = z.nextEntry
                var n = 0
                while (e != null) {
                    if (!e.isDirectory) {
                        if (e.name == "backup.json") {
                            jsonText = String(z.readBytes(), Charsets.UTF_8)
                        } else if (e.name.startsWith("media/") || e.name.startsWith("covers/")) {
                            // nome seguro: nada de sair da pasta temporária
                            val f = File(tmp, "f" + (n++))
                            FileOutputStream(f).use { z.copyTo(it) }
                            File(tmp, "index.txt").appendText(f.name + "\t" + e.name + "\n")
                        }
                    }
                    z.closeEntry()
                    e = z.nextEntry
                }
            } else {
                jsonText = String(head.readBytes(), Charsets.UTF_8)
            }
            val t = jsonText
            if (t == null) {
                tmp.deleteRecursively()
                null
            } else {
                BackupPack(t, tmp)
            }
        } catch (e: Exception) {
            try {
                tmp.deleteRecursively()
            } catch (x: Exception) {
            }
            null
        }
    }

    private fun parseCustomGenres(ga: JSONArray?, taken: (String) -> Boolean): List<Genre> {
        val r = ArrayList<Genre>()
        if (ga == null) return r
        for (i in 0 until ga.length()) {
            val o = ga.getJSONObject(i)
            val k = o.optString("key", "")
            val l = o.optString("label", "")
            if (k.isBlank() || l.isBlank() || taken(k) || r.any { it.key == k }) continue
            r.add(
                Genres.makeCustom(
                    k, l, o.optString("icon", "heart"),
                    o.optInt("color", Palette.pink), o.optString("tagline", ""), o.optString("low", ""), o.optString("mid", ""), o.optString("l9", ""), o.optString("l10", ""), colorsOf(o)
                )
            )
        }
        return r
    }

    private fun applySettings(s: JSONObject?, overwrite: Boolean) {
        if (s == null) return
        s.optJSONObject("personWd")?.let { o ->
            var any = false
            for (k in o.keys()) {
                val v = o.optString(k, "")
                if (v.isNotEmpty() && !wdMap.containsKey(k)) {
                    wdMap[k] = v
                    any = true
                }
            }
            if (any) {
                saveWd()
                version++
            }
        }
        if (overwrite) {
            for ((jk, g) in listOf("actorOrderM" to "m", "actorOrderF" to "f")) {
                val a = s.optJSONArray(jk) ?: continue
                setActorOrder(g, (0 until a.length()).map { a.optString(it) }.filter { it.isNotEmpty() })
            }
            if (s.has("tiebreak")) tiebreak = s.optString("tiebreak", "avg")
            if (s.has("podiumSort")) podiumSort = s.optString("podiumSort", "count")
            if (s.has("themeMode")) themeMode = s.optInt("themeMode", 0)
            if (s.has("textZoom")) textZoom = s.optInt("textZoom", 100)
            if (s.has("homeUrl")) homeUrl = s.optString("homeUrl", DEFAULT_HOME)
            if (s.has("userName")) userName = s.optString("userName", "")
            if (s.has("askedName")) askedName = s.optBoolean("askedName", true)
        } else {
            val n = s.optString("userName", "")
            if (userName.isBlank() && n.isNotBlank()) {
                userName = n
                askedName = true
            }
        }
    }

    /**
     * Passo 2: aplica o backup aberto por [openBackup].
     * replace = apaga o que existe e restaura tudo; senão só junta o que ainda não existe.
     * Devolve quantos doramas entraram, ou -1 se o arquivo não for um backup válido.
     */
    fun readBackup(pack: BackupPack, replace: Boolean): Int {
        return try {
            // nome dentro do zip -> arquivo temporário
            val media = HashMap<String, File>()
            val idx = File(pack.dir, "index.txt")
            if (idx.exists()) {
                for (line in idx.readLines()) {
                    val p = line.split("\t")
                    if (p.size == 2) media[p[1]] = File(pack.dir, p[0])
                }
            }
            val t = pack.json.trim()
            val root: JSONObject? = if (t.startsWith("{")) JSONObject(t) else null
            val arr: JSONArray = if (root != null) (root.optJSONArray("dramas") ?: JSONArray()) else JSONArray(t)

            // 1) lê e confere tudo antes de mexer em qualquer coisa
            val keep = ArrayList<Pair<Drama, JSONObject>>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val d = dramaFromJson(o)
                if (d.title.isBlank()) continue
                if (!replace) {
                    val dup = list.any { it.title.equals(d.title, true) && it.year == d.year } ||
                        keep.any { it.first.title.equals(d.title, true) && it.first.year == d.year }
                    if (dup) continue
                }
                keep.add(Pair(d, o))
            }
            if (replace && keep.isEmpty()) return -1

            // 2) coloca os arquivos nas pastas do app e acerta os ids
            val covDir = File(appContext.filesDir, "covers")
            val musDir = File(appContext.filesDir, "music")
            covDir.mkdirs()
            musDir.mkdirs()
            val stamp = System.currentTimeMillis()
            val used = HashSet<Long>()
            if (!replace) for (d in list) used.add(d.id)
            var next = stamp
            var seq = 0
            fun place(entryName: String, dir: File, prefix: String, ext: String): String {
                if (entryName.isEmpty()) return ""
                val src = media[entryName] ?: return ""
                if (!src.exists() || src.length() == 0L) return ""
                val dst = File(dir, prefix + stamp + "_" + (seq++) + "." + ext)
                if (!src.renameTo(dst)) {
                    src.copyTo(dst, true)
                    src.delete()
                }
                return dst.absolutePath
            }
            for (i in keep.indices) {
                val d = keep[i].first
                val o = keep[i].second
                if (!replace || used.contains(d.id)) {
                    while (used.contains(next)) next++
                    d.id = next
                }
                used.add(d.id)
                d.cover = place(o.optString("cover", ""), covDir, "c", "jpg")
                d.soundtrack = place(o.optString("soundtrack", ""), musDir, "t", "audio")
                d.couplePhoto = place(o.optString("couplePhoto", ""), covDir, "c", "jpg")
                val src = o.optJSONArray("castPeople")
                for ((k, p) in d.castPeople.withIndex()) {
                    val name = src?.optJSONObject(k)?.optString("photo", "") ?: ""
                    p.photo = place(name, covDir, "c", "jpg")
                }
            }

            // 3) aplica
            if (replace) {
                for (d in list) deleteMediaOf(d)
                list.clear()
                for (p in keep) list.add(p.first)
                if (root != null) {
                    if (root.has("genres")) {
                        Genres.setCustom(parseCustomGenres(root.optJSONArray("genres")) { Genres.factoryOf(it) != null })
                    }
                    if (root.has("genreEdits")) {
                        val m = HashMap<String, Genre>()
                        val ea = root.optJSONArray("genreEdits")
                        if (ea != null) {
                            for (i in 0 until ea.length()) {
                                val g = editFromJson(ea.getJSONObject(i)) ?: continue
                                m[g.key] = g
                            }
                        }
                        Genres.setEdits(m)
                    }
                    persistGenres()
                    if (root.has("genreOrder")) applyGenreOrder(root.optJSONArray("genreOrder"))
                    importOthers(root, true)
                    applySettings(root.optJSONObject("settings"), true)
                }
            } else {
                for (p in keep) list.add(p.first)
                if (root != null) {
                    val novos = parseCustomGenres(root.optJSONArray("genres")) { Genres.exists(it) }
                    if (novos.isNotEmpty()) {
                        Genres.setCustom(Genres.custom() + novos)
                    }
                    val ea = root.optJSONArray("genreEdits")
                    if (ea != null) {
                        val m = HashMap(Genres.edited())
                        for (i in 0 until ea.length()) {
                            val g = editFromJson(ea.getJSONObject(i)) ?: continue
                            if (!m.containsKey(g.key)) m[g.key] = g
                        }
                        Genres.setEdits(m)
                    }
                    persistGenres()
                    importOthers(root, false)
                    applySettings(root.optJSONObject("settings"), false)
                }
            }
            restorePeople(root, media, replace)
            Covers.clear()
            persist()
            keep.size
        } catch (e: Exception) {
            -1
        } finally {
            try {
                pack.dir.deleteRecursively()
            } catch (e: Exception) {
            }
        }
    }

    /** Apaga do aparelho todos os arquivos de um dorama (capa, trilha, fotos do elenco e do casal). */
    private fun deleteMediaOf(d: Drama) {
        val all = ArrayList<String>()
        all.add(d.cover)
        all.add(d.soundtrack)
        all.add(d.couplePhoto)
        for (p in d.castPeople) all.add(p.photo)
        for (f in all) {
            if (f.isEmpty()) continue
            try {
                File(f).delete()
            } catch (e: Exception) {
            }
        }
    }

    /** Copia a imagem escolhida para a pasta do app (reduzida) e devolve o caminho. */
    /** Copia o áudio escolhido para dentro do app (assim ele continua tocando mesmo se o original sumir). */
    fun saveAudio(uri: Uri): String? {
        return try {
            val dir = File(appContext.filesDir, "music")
            dir.mkdirs()
            val f = File(dir, "t" + System.currentTimeMillis() + ".audio")
            appContext.contentResolver.openInputStream(uri)?.use { i ->
                FileOutputStream(f).use { out -> i.copyTo(out) }
            } ?: return null
            f.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    fun saveCover(uri: Uri): String? {
        return try {
            val cr = appContext.contentResolver
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 2200 || bounds.outHeight / sample > 2200) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp: Bitmap = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            var rot = 0
            try {
                cr.openInputStream(uri)?.use { s ->
                    val ex = ExifInterface(s)
                    val o = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                    rot = when (o) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270
                        else -> 0
                    }
                }
            } catch (e: Exception) {
            }
            if (rot != 0) {
                val m = Matrix()
                m.postRotate(rot.toFloat())
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            // foto pequena/borrada: amplia com suavização e realça os detalhes
            bmp = ImageEnhance.autoIfSmall(bmp)
            val dir = File(appContext.filesDir, "covers")
            dir.mkdirs()
            val f = File(dir, "c" + System.currentTimeMillis() + ".jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            f.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    /** Salva uma imagem já pronta (por exemplo, o enquadramento escolhido) como JPEG em covers/. */
    fun saveBitmap(bmp: Bitmap): String? {
        return try {
            val dir = File(appContext.filesDir, "covers")
            dir.mkdirs()
            val f = File(dir, "c" + System.currentTimeMillis() + "f.jpg")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            f.absolutePath
        } catch (e: Exception) {
            null
        }
    }
}
